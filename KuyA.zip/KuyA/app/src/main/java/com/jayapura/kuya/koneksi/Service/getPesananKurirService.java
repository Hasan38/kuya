package com.jayapura.kuya.koneksi.Service;

import android.content.Context;

import com.jayapura.kuya.koneksi.ApiInterface;
import com.jayapura.kuya.koneksi.RetrofitBuilder;

import retrofit2.Callback;

public class getPesananKurirService {
    private ApiInterface api;

    public getPesananKurirService(Context context) {

        api = RetrofitBuilder.builder(context)
                .create(ApiInterface.class);
    }

    public void doGetPesananKurir(String id_kurir,double lat,double lang, Callback callback) {

        api.getPesanan(id_kurir,lat,lang).enqueue(callback);
    }
}
