package com.jayapura.kuya.koneksi.Service;

import android.content.Context;

import com.jayapura.kuya.koneksi.ApiInterface;
import com.jayapura.kuya.koneksi.RetrofitBuilder;

import retrofit2.Callback;

public class getSetoranTokoService {

    private ApiInterface api;

    public getSetoranTokoService(Context context) {

        api = RetrofitBuilder.builder(context)
                .create(ApiInterface.class);
    }

    public void doGetSetoranToko(String id_toko, Callback callback) {

        api.getSetoranToko(id_toko).enqueue(callback);
    }
}
