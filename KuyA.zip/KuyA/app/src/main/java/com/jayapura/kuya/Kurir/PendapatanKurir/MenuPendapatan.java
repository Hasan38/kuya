package com.jayapura.kuya.Kurir.PendapatanKurir;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetBehavior;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.jayapura.kuya.Kurir.Adapter.SetoranPertokoAdapter;
import com.jayapura.kuya.Constant;
import com.jayapura.kuya.Kurir.MenuKurir;
import com.jayapura.kuya.Kurir.Model.PendapatanHari;
import com.jayapura.kuya.Kurir.Model.Setoran;
import com.jayapura.kuya.Model.User;
import com.jayapura.kuya.R;
import com.jayapura.kuya.RecyclerItemClickListener;
import com.jayapura.kuya.koneksi.PrefUtil;
import com.jayapura.kuya.koneksi.Service.getPendapatanHariService;
import com.jayapura.kuya.koneksi.Service.getSetoranService;
import java.text.NumberFormat;
import java.util.Locale;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MenuPendapatan extends Fragment {
    private CardView btnPendapatanHari,btnPending,btnCancel,btnAmbil;
    private SetoranPertokoAdapter adapter;

    private TextView Tutup, Kembali,txtHariIni,txtPaket1,txtTotal,txtHarga,txtOngkir,txtTotal1;
    String id_kurir;
    getSetoranService getsetoranservice;
    getPendapatanHariService getservice;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    ProgressBar progressBar;



    public MenuPendapatan() {
        // Required empty public constructor
    }


    @Nullable
    @SuppressLint("MissingPermission")

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.menu_pendapatan_kurir, container, false);

        btnPendapatanHari=view.findViewById(R.id.btnPendapatanHariIni);
        txtHariIni=view.findViewById(R.id.txtHariIni);
        txtHarga=view.findViewById(R.id.txtHarga);
        txtOngkir=view.findViewById(R.id.txtOngkir);
        txtTotal1=view.findViewById(R.id.txtTotal1);
        txtTotal=view.findViewById(R.id.txtTotal);
        txtPaket1=view.findViewById(R.id.txtPaket1);
        Kembali=view.findViewById(R.id.Kembali);
        Tutup=view.findViewById(R.id.Tutup);



        recyclerView = view.findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        progressBar = view.findViewById(R.id.prograss);

        final View bottomsheet = view.findViewById(R.id.bottom_sheet);

        //Assign LinearLayout tersebut ke BottomSheetBehavior
        final BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.from(bottomsheet);

        //Set BottomSheet view supaya bisa disembunyikan semuanya
        bottomSheetBehavior.setHideable(true);




        btnPendapatanHari.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(bottomSheetBehavior.getState() == BottomSheetBehavior.STATE_COLLAPSED) {
                    fetchSetoran();
                    fetchPendapatanHariini();
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);

                }}
        });
        Kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuKurir()).commit();
            }
        });
        Tutup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);

            }
        });
        super.onCreate(savedInstanceState);


        return view;
    }
    private void initDataIntent(final Setoran setoran) {
        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(), new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                String harga= setoran.getData().get(position).getHarga();
                String nama_toko = setoran.getData().get(position).getNama_toko();
                String id_toko =setoran.getData().get(position).getId_toko();
                String ongkir=setoran.getData().get(position).getOngkir();
                String paket=setoran.getData().get(position).getPaket();




                Bundle detailpesanan = new Bundle();

                detailpesanan.putString(Constant.KEY_PesananSelesaiNamaToko, nama_toko);
                detailpesanan.putString(Constant.KEY_PesananSelesaiIdToko, id_toko);
                detailpesanan.putString(Constant.KEY_PesananSelesaiOngkir,ongkir);
                detailpesanan.putString(Constant.KEY_PesananSelesaiHarga,harga);
                detailpesanan.putString(Constant.KEY_PesananSelesaiPaket,paket);

                PendapatanPerTokoKurir fragment = new PendapatanPerTokoKurir();
                fragment.setArguments(detailpesanan);

                getFragmentManager()
                        .beginTransaction()
                        .replace(R.id.FrameKurir, fragment)
                        .commit();


            }
        }));
    }


    @Override
    public void onResume() {
        super.onResume();

        if(getView() == null){
            return;
        }

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK){
                    MenuKurir mainHomeFragment = new MenuKurir();
                    FragmentTransaction fragmentTransaction =
                            getActivity().getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.FrameKurir, mainHomeFragment);
                    fragmentTransaction.commit();


                    return true;

                }
                return false;
            }
        });
    }
    public void fetchPendapatanHariini() {
        User user = PrefUtil.getUser(getActivity(), PrefUtil.USER_SESSION);
        id_kurir = user.getData().get(0).getId();

        getservice = new getPendapatanHariService(getActivity());
        getservice.doGetPendapatanHari(id_kurir, new Callback() {

            @Override
            public void onResponse(Call call, Response response) {

                PendapatanHari pendapatan = (PendapatanHari) response.body();
                try {
                    if (pendapatan.getCode() == 1) {


                        String ongkir1=pendapatan.getData().get(0).getOngkir();
                        String harga1=pendapatan.getData().get(0).getSetor();

                        double ongkir=Double.parseDouble(ongkir1);
                        double harga=Double.parseDouble(harga1);
                        double total=ongkir+harga;
                        Locale localeID = new Locale("in", "ID");
                        NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(localeID);
                        txtOngkir.setText("Ongkir : " + formatRupiah.format((double) ongkir));
                        txtHarga.setText("Harga : " + formatRupiah.format((double) harga));
                        txtTotal.setText("Total : " + formatRupiah.format((double) total));
                        txtTotal1.setText("Total : " + formatRupiah.format((double) total));
                        txtPaket1.setText("Jumlah Paket :"+ pendapatan.getData().get(0).getPaket());

                    } else {

                        txtOngkir.setText("Belum Ada");
                        txtHarga.setText("Belum Ada");
                        txtTotal.setText("Belum Ada");
                        txtTotal.setText("0");
                        txtPaket1.setText("0");
                    }
                }catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call call, Throwable t) {



            }
        });
    }

    public void fetchSetoran() {
        User user = PrefUtil.getUser(getActivity(), PrefUtil.USER_SESSION);
        id_kurir = user.getData().get(0).getId();

        getsetoranservice = new getSetoranService(getActivity());
        getsetoranservice.doGetSetoran(id_kurir, new Callback() {

            @Override
            public void onResponse(Call call, Response response) {
                progressBar.setVisibility(View.GONE);
               Setoran setoran = (Setoran) response.body();
                try {
                    if (setoran.getCode() == 1) {
                        adapter = new SetoranPertokoAdapter(setoran, getActivity());
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();
                        initDataIntent(setoran);
                    } else {

                        Toast.makeText(getActivity(), setoran.getMessage(), Toast.LENGTH_LONG).show();
                        getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuPendapatan()).commit();
                    }
                }catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call call, Throwable t) {

                progressBar.setVisibility(View.GONE);

            }
        });
    }



}

