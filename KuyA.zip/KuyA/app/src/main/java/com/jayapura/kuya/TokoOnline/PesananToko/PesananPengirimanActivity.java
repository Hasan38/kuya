package com.jayapura.kuya.TokoOnline.PesananToko;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.jayapura.kuya.Constant;
import com.jayapura.kuya.Model.Pesanan;
import com.jayapura.kuya.Model.User;
import com.jayapura.kuya.R;
import com.jayapura.kuya.RecyclerItemClickListener;
import com.jayapura.kuya.TokoOnline.Adapter.PesananPengirimanTokoAdapter;
import com.jayapura.kuya.koneksi.PrefUtil;
import com.jayapura.kuya.koneksi.Service.getPesananPengirimanTokoService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PesananPengirimanActivity extends Fragment {

    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;

    private PesananPengirimanTokoAdapter adapter;
    String id_toko;
    private TextView txtPaket;

    ProgressBar progressBar;
    getPesananPengirimanTokoService getservice;



    public PesananPengirimanActivity() {
        // Required empty public constructor
    }


    @Nullable
    @SuppressLint("MissingPermission")

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.baris_pesanan_pengiriman_toko, container, false);


        txtPaket = view.findViewById(R.id.txtPaket);
        TextView Kembali = view.findViewById(R.id.Kembali);


        progressBar = view.findViewById(R.id.prograss);
        recyclerView = view.findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);

fetcdata();
        Kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.FrameToko, new MenuPesanan()).commit();
            }
        });


        final SwipeRefreshLayout dorefresh = view.findViewById(R.id.swipeRefresh);
        dorefresh.setColorSchemeResources(android.R.color.holo_blue_bright, android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_red_light);

        /*event ketika widget dijalankan*/
        dorefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refreshItem();
            }

            void refreshItem() {
                fetcdata();
                onItemLoad();
            }

            void onItemLoad() {
                dorefresh.setRefreshing(false);
            }

        });


        return view;
    }


    @Override
    public void onResume() {
        super.onResume();

        if (getView() == null) {
            return;
        }

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    MenuPesanan mainHomeFragment = new MenuPesanan();
                    FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.FrameToko, mainHomeFragment);
                    fragmentTransaction.commit();


                    return true;

                }
                return false;
            }
        });
    }

    private void initDataIntent(final Pesanan pesanan) {
        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(), new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                String no_pesan = pesanan.getData().get(position).getNo_pesan();
                String alamat_pelanggan = pesanan.getData().get(position).getAlamat_pelanggan();
                String tlp_pelanggan1 = pesanan.getData().get(position).getTlp_pelanggan1();
                String tlp_pelanggan2 = pesanan.getData().get(position).getTlp_pelanggan2();
                String nama_toko = pesanan.getData().get(position).getNama_toko();
                String ongkir = pesanan.getData().get(position).getOngkir();
                String harga = pesanan.getData().get(position).getHarga();
                String lat = String.valueOf(pesanan.getData().get(position).getLat());
                String lang = String.valueOf(pesanan.getData().get(position).getLang());
                String tlp_toko = pesanan.getData().get(position).getTlp_toko();
                String nama_pelanggan = pesanan.getData().get(position).getNama_pelanggan();


                Bundle detailpesanan = new Bundle();
                detailpesanan.putString(Constant.KEY_PesananNoPesanan, no_pesan);
                detailpesanan.putString(Constant.KEY_PesananAlamatPelanggan, alamat_pelanggan);
                detailpesanan.putString(Constant.KEY_PesananTlp1, tlp_pelanggan1);
                detailpesanan.putString(Constant.KEY_PesananTlp2, tlp_pelanggan2);
                detailpesanan.putString(Constant.KEY_PesananNamaToko, nama_toko);
                detailpesanan.putString(Constant.KEY_PesananOngkir, ongkir);
                detailpesanan.putString(Constant.KEY_PesananHarga, harga);
                detailpesanan.putString(Constant.KEY_PesananLat, lat);
                detailpesanan.putString(Constant.KEY_PesananLang, lang);
                detailpesanan.putString(Constant.KEY_PesananTlpToko, tlp_toko);
                detailpesanan.putString(Constant.KEY_PesananNamaPelanggan, nama_pelanggan);

                DetailPesananPengirimanToko fragment = new DetailPesananPengirimanToko();
                fragment.setArguments(detailpesanan);

                getFragmentManager().beginTransaction().replace(R.id.FrameToko, fragment).commit();


            }
        }));
    }

    private void showDialog() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());

        // set title dialog
        alertDialogBuilder.setTitle("Halo brooooo?");

        // set pesan dari dialog
        alertDialogBuilder.setMessage("Tidak Ada Data......!").setIcon(R.mipmap.ic_launcher)

                .setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        getFragmentManager().beginTransaction().replace(R.id.FrameToko, new MenuPesanan()).commit();
                    }
                });


        // membuat alert dialog dari builder
        AlertDialog alertDialog = alertDialogBuilder.create();

        // menampilkan alert dialog
        alertDialog.show();
    }
public void fetcdata(){
    User user = PrefUtil.getUser(getActivity(), PrefUtil.USER_SESSION);
    id_toko = user.getData().get(0).getId();

    getservice = new getPesananPengirimanTokoService(getActivity());
    getservice.doGetPesananPengiriman(id_toko, new Callback() {

        @Override
        public void onResponse(Call call, Response response) {
            progressBar.setVisibility(View.GONE);
            Pesanan pesanan = (Pesanan) response.body();
            try {
                if (pesanan.getCode() == 1) {
                    adapter = new PesananPengirimanTokoAdapter(pesanan, getActivity());
                    recyclerView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                    txtPaket.setText("Jumlah Paket: "+pesanan.getPaket()+" Paket");
                    initDataIntent(pesanan);
                } else {


                    getFragmentManager().beginTransaction().replace(R.id.FrameToko, new MenuPesanan()).commit();
                }
            }catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onFailure(Call call, Throwable t) {

            progressBar.setVisibility(View.GONE);

        }
    });

}
}



