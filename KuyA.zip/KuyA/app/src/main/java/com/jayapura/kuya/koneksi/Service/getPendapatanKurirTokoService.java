package com.jayapura.kuya.koneksi.Service;

import android.content.Context;

import com.jayapura.kuya.koneksi.ApiInterface;
import com.jayapura.kuya.koneksi.RetrofitBuilder;

import retrofit2.Callback;

public class getPendapatanKurirTokoService {

    private ApiInterface api;

    public getPendapatanKurirTokoService (Context context) {

        api = RetrofitBuilder.builder(context)
                .create(ApiInterface.class);
    }

    public void doGetPesananKurirToko(String id_kurir,String id_toko,  Callback callback) {

        api.getPesananSelesai(id_kurir,id_toko).enqueue(callback);
    }
}
