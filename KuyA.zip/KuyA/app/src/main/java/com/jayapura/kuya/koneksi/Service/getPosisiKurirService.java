package com.jayapura.kuya.koneksi.Service;

import android.content.Context;

import com.jayapura.kuya.koneksi.ApiInterface;
import com.jayapura.kuya.koneksi.RetrofitBuilder;

import retrofit2.Callback;

public class getPosisiKurirService {

    private ApiInterface api;

    public getPosisiKurirService (Context context) {

        api = RetrofitBuilder.builder(context)
                .create(ApiInterface.class);
    }

    public void doGetPosisi(String id_toko, Callback callback) {

        api.getPosisi(id_toko).enqueue(callback);
    }
}
