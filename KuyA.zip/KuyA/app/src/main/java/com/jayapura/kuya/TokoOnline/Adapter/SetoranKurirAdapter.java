package com.jayapura.kuya.TokoOnline.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.jayapura.kuya.Kurir.Model.Setoran;
import com.jayapura.kuya.R;

import java.text.NumberFormat;
import java.util.Locale;

public class SetoranKurirAdapter extends RecyclerView.Adapter<SetoranKurirAdapter.MyViewHolder> {

    private Setoran setoran;

    private Context context;


    public SetoranKurirAdapter(Setoran setoran, Context context) {
        this.setoran = setoran;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.setoran_item_toko, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {


        String ongkir1=setoran.getData().get(position).getOngkir();
        String harga1=setoran.getData().get(position).getHarga();

        double ongkir=Double.parseDouble(ongkir1);
        double harga=Double.parseDouble(harga1);
        double total=ongkir+harga;
        Locale localeID = new Locale("in", "ID");
        NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(localeID);
        holder.txtNamaKurir.setText("Nama Kurir: " +setoran.getData().get(position).getNama_kurir());
        holder.txtPaket.setText("Jumlah Paket : " +setoran.getData().get(position).getPaket());
        holder.txtHarga.setText("Total Harga Barang : " + formatRupiah.format((double) harga));
        holder.txtOngkir.setText("Total Ongkir : " + formatRupiah.format((double) ongkir));
        holder.txtTotal.setText("Grand Total : " + formatRupiah.format((double) total));




    }

    @Override
    public int getItemCount() {
        return setoran.getData().size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView txtNamaKurir,txtHarga,txtPaket,txtTotal,txtOngkir;

        public MyViewHolder(View itemView) {
            super(itemView);
            txtNamaKurir= itemView.findViewById(R.id.txtNamaKurir);
            txtHarga = itemView.findViewById(R.id.txtHarga);
            txtOngkir= itemView.findViewById(R.id.txtOngkir);
            txtTotal=itemView.findViewById(R.id.txtTotal);
            txtPaket=itemView.findViewById(R.id.txtPaket);

        }
    }

}


