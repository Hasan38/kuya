package com.jayapura.kuya.Kurir.Toko;


import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.jayapura.kuya.Kurir.Adapter.TokoAdapter;
import com.jayapura.kuya.Kurir.MenuKurir;
import com.jayapura.kuya.Kurir.Model.Toko;
import com.jayapura.kuya.Model.User;
import com.jayapura.kuya.R;
import com.jayapura.kuya.koneksi.PrefUtil;
import com.jayapura.kuya.koneksi.Service.getTokoService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TokoActivity  extends Fragment {


    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;

    private TokoAdapter adapter;


    ProgressBar progressBar;
    getTokoService getservice;


    public TokoActivity() {
        // Required empty public constructor
    }


    @Nullable
    @SuppressLint("MissingPermission")

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.baris_pesanan_kurir, container, false);



        TextView Kembali=view.findViewById(R.id.Kembali);




        progressBar = view.findViewById(R.id.prograss);
        recyclerView = view.findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);


        Kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuKurir()).commit();
            }
        });




        fetchSpbu();

        final SwipeRefreshLayout dorefresh = view.findViewById(R.id.swipeRefresh);
        dorefresh.setColorSchemeResources(android.R.color.holo_blue_bright, android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_red_light);

        /*event ketika widget dijalankan*/
        dorefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refreshItem();
            }

            void refreshItem() {
                fetchSpbu();
                onItemLoad();
            }

            void onItemLoad() {
                dorefresh.setRefreshing(false);
            }

        });


        return view;
    }



    @Override
    public void onResume() {
        super.onResume();

        if(getView() == null){
            return;
        }

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK){
                    MenuKurir mainHomeFragment = new MenuKurir();
                    FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.FrameKurir, mainHomeFragment);
                    fragmentTransaction.commit();


                    return true;

                }
                return false;
            }
        });
    }


    private void showDialog() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());

        // set title dialog
        alertDialogBuilder.setTitle("Halo brooooo?");

        // set pesan dari dialog
        alertDialogBuilder.setMessage("Tidak Ada Data......!").setIcon(R.mipmap.ic_launcher)

                .setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuKurir()).commit();
                    }
                });


        // membuat alert dialog dari builder
        AlertDialog alertDialog = alertDialogBuilder.create();

        // menampilkan alert dialog
        alertDialog.show();
    }

    public void fetchSpbu() {
        User user = PrefUtil.getUser(getActivity(), PrefUtil.USER_SESSION);


        getservice = new getTokoService(getActivity());
        getservice.doGetToko( new Callback() {

            @Override
            public void onResponse(Call call, Response response) {
                progressBar.setVisibility(View.GONE);
               Toko toko = (Toko) response.body();
                try {
                    if (toko.getCode() == 1) {
                        adapter = new TokoAdapter(toko, getActivity());
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();


                    } else {

                        Toast.makeText(getActivity(), toko.getMessage(), Toast.LENGTH_LONG).show();
                        getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuKurir()).commit();
                    }
                }catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call call, Throwable t) {

                progressBar.setVisibility(View.GONE);

            }
        });
    }



}
