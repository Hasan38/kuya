package com.jayapura.kuya.Kurir.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SetoranData {

    @SerializedName("paket")
    @Expose
    private String paket;

    @SerializedName("ongkir")
    @Expose
    private String ongkir;

    public String getPaket() {
        return paket;
    }

    public void setPaket(String paket) {
        this.paket = paket;
    }

    public String getOngkir() {
        return ongkir;
    }

    public void setOngkir(String ongkir) {
        this.ongkir = ongkir;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getNama_toko() {
        return nama_toko;
    }

    public void setNama_toko(String nama_toko) {
        this.nama_toko = nama_toko;
    }

    @SerializedName("harga")
    @Expose
    private String harga;

    @SerializedName("nama_toko")
    @Expose
    private String nama_toko;

    public String getId_toko() {
        return id_toko;
    }

    public void setId_toko(String id_toko) {
        this.id_toko = id_toko;
    }

    @SerializedName("id_toko")
    @Expose
    private String id_toko;

    public String getNama_kurir() {
        return nama_kurir;
    }

    public void setNama_kurir(String nama_kurir) {
        this.nama_kurir = nama_kurir;
    }

    @SerializedName("nama_kurir")
    @Expose
    private String nama_kurir;
}
