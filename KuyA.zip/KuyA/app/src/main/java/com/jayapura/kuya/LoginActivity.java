package com.jayapura.kuya;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.jayapura.kuya.Model.User;
import com.jayapura.kuya.koneksi.PrefUtil;
import com.jayapura.kuya.koneksi.Service.LoginService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class LoginActivity extends AppCompatActivity {
    private static final String TAG = "LoginActivity";
    private static final int REQUEST_SIGNUP = 0;
    private EditText _emailText,_passwordText;
    private Button _loginButton;
    private TextView _signupLink;
    LoginService loginservice;

    public static void start(Context context) {
        Intent intent = new Intent(context, LoginActivity.class);
        context.startActivity(intent);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        _emailText =findViewById(R.id.input_email) ;
         _passwordText=findViewById(R.id.input_password) ;
         _loginButton=findViewById(R.id.btn_login);
         _signupLink=findViewById(R.id.link_signup);
        _loginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                login();
            }
        });

        _signupLink.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // Start the Signup activity
                Intent intent = new Intent(getApplicationContext(), SignupActivity.class);
                startActivityForResult(intent, REQUEST_SIGNUP);
            }
        });


        if(isSessionLogin()) {
            String level = PrefUtil.getString(this,PrefUtil.Usertype);
            if(level.equals("Kurir")) {
                MainActivityKurir.start(this);
                LoginActivity.this.finish();
            }else{
                MainActivity.start(this);
                LoginActivity.this.finish();
            }
        }
    }

    public void login() {
        Log.d(TAG, "Login");

        String email = _emailText.getText().toString();
        String password = _passwordText.getText().toString();

        if (TextUtils.isEmpty(email) || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(getBaseContext(), "Masukan Email yang Valid", Toast.LENGTH_LONG).show();
            return;
        }

        if (TextUtils.isEmpty(password) || password.length() < 4) {
            Toast.makeText(getBaseContext(), "Masukan Password Min 4 Karakter", Toast.LENGTH_LONG).show();
            return;
        }



        final ProgressDialog progressDialog = new ProgressDialog(LoginActivity.this,
                R.style.AppTheme_Dark_Dialog);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Authenticating...");
        progressDialog.show();



        loginservice = new LoginService(this);
        loginservice.doLogin(email, password,  new Callback() {
            @Override
            public void onResponse(Call call, Response response) {
                User user = (User) response.body();

                if (user.getCode() == 1) {

                    String Level = user.getData().get(0).getUsertype();


                    if (Level.equals("Kurir")) {
                        PrefUtil.putUser(LoginActivity.this, PrefUtil.USER_SESSION, user);
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Email, user.getData().get(0).getEmail());
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Password, user.getData().get(0).getPassword());
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Nama, user.getData().get(0).getNama());
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Alamat, user.getData().get(0).getAlamat());
                        double lats = user.getData().get(0).getLat();
                        double langs = user.getData().get(0).getLang();
                        String lat = Double.toString(lats);
                        String lang = Double.toString(langs);
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Lat, lat);
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Lang, lang);

                        PrefUtil.putString(LoginActivity.this, PrefUtil.Tlp, user.getData().get(0).getTlp());
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Kecamatan, user.getData().get(0).getKecamatan());
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Kabupaten, user.getData().get(0).getKabupaten());
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Usertype, user.getData().get(0).getUsertype());
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Img, user.getData().get(0).getImg());


                        MainActivityKurir.start(LoginActivity.this);
                        LoginActivity.this.finish();
                        Toast.makeText(LoginActivity.this, user.getMessage(), Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    } else if (Level.equals("Toko Online")) {
                        PrefUtil.putUser(LoginActivity.this, PrefUtil.USER_SESSION, user);
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Email, user.getData().get(0).getEmail());
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Password, user.getData().get(0).getPassword());
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Nama, user.getData().get(0).getNama());
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Nama_toko, user.getData().get(0).getNama_toko());
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Alamat, user.getData().get(0).getAlamat());
                        double lats = user.getData().get(0).getLat();
                        double langs = user.getData().get(0).getLang();
                        String lat = Double.toString(lats);
                        String lang = Double.toString(langs);
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Lat, lat);
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Lang, lang);
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Tlp, user.getData().get(0).getTlp());
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Kecamatan, user.getData().get(0).getKecamatan());
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Kabupaten, user.getData().get(0).getKabupaten());
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Usertype, user.getData().get(0).getUsertype());
                        PrefUtil.putString(LoginActivity.this, PrefUtil.Img, user.getData().get(0).getImg());


                        MainActivity.start(LoginActivity.this);
                        LoginActivity.this.finish();
                        Toast.makeText(LoginActivity.this, user.getMessage(), Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    }

                    /********************************************************************************************/
                } else {
                    progressDialog.dismiss();
                    Toast.makeText(LoginActivity.this, user.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call call, Throwable t) {
                Toast.makeText(LoginActivity.this, "An error occurred!", Toast.LENGTH_SHORT).show();
            }
        });



    }



    @Override
    public void onBackPressed() {
        // disable going back to the MainActivity
        moveTaskToBack(true);
        this.finish();
    }





    boolean isSessionLogin() {
        return PrefUtil.getUser(this, PrefUtil.USER_SESSION) != null;
    }
}
