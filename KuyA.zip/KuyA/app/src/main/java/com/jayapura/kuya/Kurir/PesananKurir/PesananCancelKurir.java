package com.jayapura.kuya.Kurir.PesananKurir;



import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.jayapura.kuya.Kurir.Adapter.PesananCancelKurirAdapter;
import com.jayapura.kuya.Constant;
import com.jayapura.kuya.Model.Pesanan;
import com.jayapura.kuya.Model.User;
import com.jayapura.kuya.R;
import com.jayapura.kuya.RecyclerItemClickListener;
import com.jayapura.kuya.koneksi.PrefUtil;
import com.jayapura.kuya.koneksi.Service.getPesananCancelKurirService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PesananCancelKurir extends Fragment {

    private static final String TAG = PesananActivityKurir.class.getSimpleName();
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;

    private PesananCancelKurirAdapter adapter;
    private Toolbar toolbarMain;
    String id_kurir;
    private TextView txtPaket;

    ProgressBar progressBar;
    getPesananCancelKurirService getservice;

    public PesananCancelKurir() {
        // Required empty public constructor
    }


    @Nullable
    @SuppressLint("MissingPermission")

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.baris_pesanan_cancel_kurir, container, false);


        txtPaket=view.findViewById(R.id.txtPaket);
        TextView Kembali=view.findViewById(R.id.Kembali);




        progressBar = view.findViewById(R.id.prograss);
        recyclerView = view.findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);


        Kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuPesanan()).commit();
            }
        });




        fetchPrestasi();

        final SwipeRefreshLayout dorefresh = view.findViewById(R.id.swipeRefresh);
        dorefresh.setColorSchemeResources(android.R.color.holo_blue_bright, android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_red_light);

        /*event ketika widget dijalankan*/
        dorefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refreshItem();
            }

            void refreshItem() {
                fetchPrestasi();
                onItemLoad();
            }

            void onItemLoad() {
                dorefresh.setRefreshing(false);
            }

        });


        return view;
    }




    @Override
    public void onResume() {
        super.onResume();

        if(getView() == null){
            return;
        }

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK){
                    MenuPesanan mainHomeFragment = new MenuPesanan();
                    FragmentTransaction fragmentTransaction =
                            getActivity().getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.FrameKurir, mainHomeFragment);
                    fragmentTransaction.commit();


                    return true;

                }
                return false;
            }
        });
    }

    private void initDataIntent(final Pesanan pesanan) {
        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(), new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                String no_pesan = pesanan.getData().get(position).getNo_pesan();
                String alamat_pelanggan = pesanan.getData().get(position).getAlamat_pelanggan();
                String tlp_pelanggan1 = pesanan.getData().get(position).getTlp_pelanggan1();
                String tlp_pelanggan2= pesanan.getData().get(position).getTlp_pelanggan2();
                String nama_toko = pesanan.getData().get(position).getNama_toko();
                String ongkir=pesanan.getData().get(position).getOngkir();
                String harga=pesanan.getData().get(position).getHarga();
                String lat=String.valueOf(pesanan.getData().get(position).getLat());
                String lang= String.valueOf(pesanan.getData().get(position).getLang());
                String tlp_toko= pesanan.getData().get(position).getTlp_toko();
                String nama_pelanggan=pesanan.getData().get(position).getNama_pelanggan();


                Bundle detailpesanan = new Bundle();
                detailpesanan.putString(Constant.KEY_PesananCancelNoPesanan, no_pesan);
                detailpesanan.putString(Constant.KEY_PesananCancelAlamatPelanggan, alamat_pelanggan);
                detailpesanan.putString(Constant.KEY_PesananCancelTlp1, tlp_pelanggan1);
                detailpesanan.putString(Constant.KEY_PesananCancelTlp2, tlp_pelanggan2);
                detailpesanan.putString(Constant.KEY_PesananCancelNamaToko, nama_toko);
                detailpesanan.putString(Constant.KEY_PesananCancelOngkir,ongkir);
                detailpesanan.putString(Constant.KEY_PesananCancelHarga,harga);

                detailpesanan.putString(Constant.KEY_PesananCancelTlpToko, tlp_toko);
                detailpesanan.putString(Constant.KEY_PesananCancelNamaPelanggan, nama_pelanggan);

                DetailPesananCancelKurir fragment = new DetailPesananCancelKurir();
                fragment.setArguments(detailpesanan);

                getFragmentManager()
                        .beginTransaction()
                        .replace(R.id.FrameKurir, fragment)
                        .commit();


            }
        }));
    }

    private void showDialog() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());

        // set title dialog
        alertDialogBuilder.setTitle("Halo brooooo?");

        // set pesan dari dialog
        alertDialogBuilder.setMessage("Tidak Ada Data......!").setIcon(R.mipmap.ic_launcher)

                .setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuPesanan()).commit();
                    }
                });


        // membuat alert dialog dari builder
        AlertDialog alertDialog = alertDialogBuilder.create();

        // menampilkan alert dialog
        alertDialog.show();
    }

    public void fetchPrestasi() {
        User user = PrefUtil.getUser(getActivity(), PrefUtil.USER_SESSION);
        id_kurir = user.getData().get(0).getId();

        getservice = new getPesananCancelKurirService(getActivity());
        getservice.doGetPesananCancelKurir(id_kurir, new Callback() {

            @Override
            public void onResponse(Call call, Response response) {
                progressBar.setVisibility(View.GONE);
                Pesanan pesanan = (Pesanan) response.body();
                try {
                    if (pesanan.getCode() == 1) {
                        adapter = new PesananCancelKurirAdapter(pesanan, getActivity());
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();
                        txtPaket.setText("Jumlah Paket: "+pesanan.getPaket()+" Paket");
                        initDataIntent(pesanan);
                    } else {


                        getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuPesanan()).commit();
                    }
                }catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call call, Throwable t) {

                progressBar.setVisibility(View.GONE);

            }
        });
    }


}