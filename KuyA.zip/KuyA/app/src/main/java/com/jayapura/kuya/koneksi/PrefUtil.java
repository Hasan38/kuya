package com.jayapura.kuya.koneksi;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.jayapura.kuya.Model.User;
import com.google.gson.Gson;


/**
 * Created by Wim on 11/3/16.
 */
public class PrefUtil {

    public static final String USER_SESSION = "user_session";
    public static final String Email="email";
    public static final String Password="password";
    public static final String Nama="nama";
    public static final String Alamat="alamat";
    public static final String Tlp="tlp";
    public static final String Nama_toko="nama_toko";

    public static final String Kecamatan="kecamatan";
    public static final String Kabupaten="kabupaten";
    public static final String Lat="lat";
    public static final String Lang="lang";
    public static final String Usertype="usertype";
    public static final String Id="id";
    public static final String Img="img";
    public static final String SP_SUDAH_LOGIN = "spSudahLogin";

    SharedPreferences sp;

    public static SharedPreferences getSharedPreference(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static void putUser(Context context, String key, User user) {
        Gson gson = new Gson();
        String json = gson.toJson(user);
        putString(context, key, json);
    }

    public static User getUser(Context context, String key) {
        Gson gson = new Gson();
        String json = getString(context, key);
        User user = gson.fromJson(json, User.class);
        return user;
    }

    public static void putString(Context context, String key, String value) {
        getSharedPreference(context).edit().putString(key, value).apply();
    }

    public static String getString(Context context, String key) {
        return getSharedPreference(context).getString(key, null);
    }

    public static void clear(Context context) {
        getSharedPreference(context).edit().clear().apply();
    }
    public Boolean getSPSudahLogin(){
        return sp.getBoolean(SP_SUDAH_LOGIN, false);
    }

}
