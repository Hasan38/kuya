package com.jayapura.kuya.Kurir.PesananKurir;



import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.jayapura.kuya.Constant;
import com.jayapura.kuya.Model.Pesanan;
import com.jayapura.kuya.R;
import com.jayapura.kuya.koneksi.Service.UpdatePesananService;

import java.text.NumberFormat;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailPesananAmbilKurir extends Fragment  {
    UpdatePesananService updatepes;

    private TextView txtNoPesanan,imgTlp1, imgTlp2,txtJenisBarang, txtNamaToko, Kembali, txtAlamat, txtTlpToko, txtHarga, txtOngkir, txtNama, txtTotal;
    private ProgressDialog progressDialog;
    String no_pesan, nama_pelanggan,jenis_barang, alamat_pelanggan, tlp_pelanggan1, tlp_pelanggan2, nama_toko, tlp_toko, ongkir, harga;
    private ImageView btnAmbil,btnBatal;

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.main_pesanan_ambil_kurir, container, false);
        txtNama = view.findViewById(R.id.txtNama);
        txtNamaToko = (TextView) view.findViewById(R.id.txtNamaToko);
        txtAlamat = (TextView) view.findViewById(R.id.txtAlamat);


        txtHarga = (TextView) view.findViewById(R.id.txtHarga);
        txtOngkir = (TextView) view.findViewById(R.id.txtOngkir);
        txtTotal = (TextView) view.findViewById(R.id.txtTotal);
        txtTlpToko = view.findViewById(R.id.txtTlpToko);
        imgTlp1 = view.findViewById(R.id.txtTlp1);
        imgTlp2 = view.findViewById(R.id.txtTlp2);
        Kembali = view.findViewById(R.id.Kembali);
        btnBatal=view.findViewById(R.id.btnBatal);
        btnAmbil=view.findViewById(R.id.btnAmbil);
        txtNoPesanan=view.findViewById(R.id.txtNoPesanan);
        txtJenisBarang=view.findViewById(R.id.txtJenisBarang);


        Bundle bundle = this.getArguments();

        nama_pelanggan = bundle.getString(Constant.KEY_PesananAmbilNamaPelanggan);
        nama_toko = bundle.getString(Constant.KEY_PesananAmbilNamaToko);
        no_pesan=bundle.getString(Constant.KEY_PesananAmbilNoPesanan);
        alamat_pelanggan = bundle.getString(Constant.KEY_PesananAmbilAlamatPelanggan);
        tlp_pelanggan1 = bundle.getString(Constant.KEY_PesananAmbilTlp1);
        tlp_pelanggan2 = bundle.getString(Constant.KEY_PesananAmbilTlp2);
        jenis_barang=bundle.getString(Constant.KEY_PesananAmbilJenisBarang);
        ongkir = bundle.getString(Constant.KEY_PesananAmbilOngkir);
        harga = bundle.getString(Constant.KEY_PesananAmbilHarga);
        tlp_toko = bundle.getString(Constant.KEY_PesananAmbilTlpToko);

        double ongkir1 = Double.parseDouble(ongkir);
        double harga1 = Double.parseDouble(harga);
        double total = ongkir1 + harga1;
        progressDialog = new ProgressDialog(getActivity());

        Locale localeID = new Locale("in", "ID");
        NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(localeID);
        txtOngkir.setText("Ongkir : " + formatRupiah.format((double) ongkir1));
        txtHarga.setText("Harga : " + formatRupiah.format((double) harga1));
        txtTotal.setText("Total : " + formatRupiah.format((double) total));
        txtNoPesanan.setText("No. Pesanan : " + no_pesan);
        txtJenisBarang.setText("Jenis Barang: " + jenis_barang);
        txtNama.setText("Nama : " + nama_pelanggan);
        txtNamaToko.setText(nama_toko);
        txtAlamat.setText(alamat_pelanggan);
        imgTlp1.setText(tlp_pelanggan1);
        imgTlp2.setText(tlp_pelanggan2);
        txtTlpToko.setText(tlp_toko);

        final LinearLayout linear1 = (LinearLayout) view.findViewById(R.id.linear1);
        final LinearLayout linear2 = (LinearLayout) view.findViewById(R.id.linear2);
        final LinearLayout linearPengirim = (LinearLayout) view.findViewById(R.id.linearPengirim);
        final LinearLayout linearPengirimIsi = (LinearLayout) view.findViewById(R.id.linearPengirimIsi);
        final LinearLayout isiCustomer = (LinearLayout) view.findViewById(R.id.isiCustomer);

        Kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new PesananAmbilKurir()).commit();
            }
        });
        imgTlp1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialContactPhoneTlp1();
            }
        });

        imgTlp2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialContactPhoneTlp2();
            }
        });

        txtTlpToko.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialContactPhoneToko();
            }
        });
        linear1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                linear2.setVisibility(View.VISIBLE);
                linear1.setVisibility(View.GONE);
                isiCustomer.setVisibility(View.VISIBLE);

            }
        });

        linear2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                linear2.setVisibility(View.GONE);
                linear1.setVisibility(View.VISIBLE);
                isiCustomer.setVisibility(View.GONE);


            }
        });
        linearPengirim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                linearPengirimIsi.setVisibility(View.VISIBLE);
                linearPengirim.setVisibility(View.GONE);
                txtNamaToko.setVisibility(View.VISIBLE);
                txtTlpToko.setVisibility(View.VISIBLE);

            }
        });

        linearPengirimIsi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                linearPengirimIsi.setVisibility(View.GONE);
                linearPengirim.setVisibility(View.VISIBLE);
                txtNamaToko.setVisibility(View.GONE);
                txtTlpToko.setVisibility(View.GONE);


            }
        });


        btnAmbil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String status_pesan="Pengiriman";

                update(status_pesan);


            }
        });

        btnBatal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String status_pesan="Cancel";

                update(status_pesan);


            }
        });

        return view;
    }


    @Override
    public void onResume() {
        super.onResume();

        if (getView() == null) {
            return;
        }

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    PesananAmbilKurir mainHomeFragment = new PesananAmbilKurir();
                    FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.FrameKurir, mainHomeFragment);
                    fragmentTransaction.commit();


                    return true;

                }
                return false;
            }
        });
    }

    private void dialContactPhoneToko() {
        String phoneNumber = tlp_toko;
        startActivity(new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phoneNumber, null)));
    }

    private void dialContactPhoneTlp1() {
        String phoneNumber = tlp_pelanggan1;
        startActivity(new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phoneNumber, null)));
    }

    private void dialContactPhoneTlp2() {
        String phoneNumber = tlp_pelanggan2;
        startActivity(new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phoneNumber, null)));
    }



    public void update(String status_pesanan) {


        updatepes = new UpdatePesananService(getActivity());
        updatepes.doUpdate(no_pesan, status_pesanan, new Callback() {
            @Override
            public void onResponse(Call call, Response response) {
                Pesanan pesan = (Pesanan) response.body();
                progressDialog.dismiss();
                if (pesan.getCode() == 1) {
                    Toast.makeText(getActivity(), pesan.getMessage(), Toast.LENGTH_SHORT).show();
                    getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new PesananPendingKurir()).commit();

                }else{
                    Toast.makeText(getActivity(), pesan.getMessage(), Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onFailure(Call call, Throwable t) {
                progressDialog.dismiss();
            }
        });

    }

}