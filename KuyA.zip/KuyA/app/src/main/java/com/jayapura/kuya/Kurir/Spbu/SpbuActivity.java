package com.jayapura.kuya.Kurir.Spbu;





import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.jayapura.kuya.Kurir.Adapter.SpbuAdapter;
import com.jayapura.kuya.BuildConfig;
import com.jayapura.kuya.Constant;
import com.jayapura.kuya.Kurir.MenuKurir;
import com.jayapura.kuya.Kurir.Model.Spbu;
import com.jayapura.kuya.Model.User;
import com.jayapura.kuya.R;
import com.jayapura.kuya.RecyclerItemClickListener;
import com.jayapura.kuya.koneksi.PrefUtil;
import com.jayapura.kuya.koneksi.Service.getSpbuService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SpbuActivity  extends Fragment {

        private static final String TAG = com.jayapura.kuya.Kurir.PesananKurir.PesananActivityKurir.class.getSimpleName();
        private RecyclerView recyclerView;
        private RecyclerView.LayoutManager layoutManager;

        private SpbuAdapter adapter;
        private Toolbar toolbarMain;
        double lat, lang;
        ProgressBar progressBar;
        getSpbuService getservice;
        private static final int REQUEST_PERMISSIONS_REQUEST_CODE = 34;
        private FusedLocationProviderClient mFusedLocationClient;

        protected Location mLastLocation;

        public SpbuActivity() {
            // Required empty public constructor
        }


        @Nullable
        @SuppressLint("MissingPermission")

        @Override
        public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            View view = inflater.inflate(R.layout.baris_pesanan_kurir, container, false);



            TextView Kembali=view.findViewById(R.id.Kembali);




            progressBar = view.findViewById(R.id.prograss);
            recyclerView = view.findViewById(R.id.recyclerView);
            layoutManager = new LinearLayoutManager(getActivity());
            recyclerView.setLayoutManager(layoutManager);
            recyclerView.setHasFixedSize(true);
            mFusedLocationClient = LocationServices.getFusedLocationProviderClient(getActivity());

            Kembali.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuKurir()).commit();
                }
            });




            fetchSpbu();

            final SwipeRefreshLayout dorefresh = view.findViewById(R.id.swipeRefresh);
            dorefresh.setColorSchemeResources(android.R.color.holo_blue_bright, android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_red_light);

            /*event ketika widget dijalankan*/
            dorefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    refreshItem();
                }

                void refreshItem() {
                    fetchSpbu();
                    onItemLoad();
                }

                void onItemLoad() {
                    dorefresh.setRefreshing(false);
                }

            });


            return view;
        }
        @Override
        public void onStart() {
            super.onStart();

            if (!checkPermissions()) {
                requestPermissions();
            } else {
                getLastLocation();

            }
        }


        @SuppressWarnings("MissingPermission")
        private void getLastLocation() {
            mFusedLocationClient.getLastLocation()
                    .addOnCompleteListener(getActivity(), new OnCompleteListener<Location>() {
                        @Override
                        public void onComplete(@NonNull Task<Location> task) {
                            if (task.isSuccessful() && task.getResult() != null) {
                                mLastLocation = task.getResult();
                                lat=mLastLocation.getLatitude();
                                lang=mLastLocation.getLongitude();
                                fetchSpbu();
                            } else {
                                Log.w(TAG, "getLastLocation:exception", task.getException());

                            }
                        }
                    });
        }
        private boolean checkPermissions() {
            int permissionState = ActivityCompat.checkSelfPermission(getActivity(),
                    Manifest.permission.ACCESS_COARSE_LOCATION);
            return permissionState == PackageManager.PERMISSION_GRANTED;
        }
        private void showSnackbar(final int mainTextStringId, final int actionStringId,
                                  View.OnClickListener listener) {

            Snackbar.make(getView().findViewById(android.R.id.content),
                    getString(mainTextStringId),
                    Snackbar.LENGTH_INDEFINITE)
                    .setAction(getString(actionStringId), listener).show();
        }
        private void startLocationPermissionRequest() {
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                    REQUEST_PERMISSIONS_REQUEST_CODE);
        }

        private void requestPermissions() {
            boolean shouldProvideRationale =
                    ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                            Manifest.permission.ACCESS_COARSE_LOCATION);

            // Provide an additional rationale to the user. This would happen if the user denied the
            // request previously, but didn't check the "Don't ask again" checkbox.
            if (shouldProvideRationale) {
                Log.i(TAG, "Displaying permission rationale to provide additional context.");

                showSnackbar(R.string.permission_rationale, android.R.string.ok,
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                // Request permission
                                startLocationPermissionRequest();
                            }
                        });

            } else {
                Log.i(TAG, "Requesting permission");
                // Request permission. It's possible this can be auto answered if device policy
                // sets the permission in a given state or the user denied the permission
                // previously and checked "Never ask again".
                startLocationPermissionRequest();
            }
        }

        @Override
        public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                               @NonNull int[] grantResults) {
            Log.i(TAG, "onRequestPermissionResult");
            if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
                if (grantResults.length <= 0) {
                    // If user interaction was interrupted, the permission request is cancelled and you
                    // receive empty arrays.
                    Log.i(TAG, "User interaction was cancelled.");
                } else if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission granted.
                    getLastLocation();
                } else {
                    // Permission denied.

                    // Notify the user via a SnackBar that they have rejected a core permission for the
                    // app, which makes the Activity useless. In a real app, core permissions would
                    // typically be best requested during a welcome-screen flow.

                    // Additionally, it is important to remember that a permission might have been
                    // rejected without asking the user for permission (device policy or "Never ask
                    // again" prompts). Therefore, a user interface affordance is typically implemented
                    // when permissions are denied. Otherwise, your app could appear unresponsive to
                    // touches or interactions which have required permissions.
                    showSnackbar(R.string.permission_denied_explanation, R.string.settings,
                            new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    // Build intent that displays the App settings screen.
                                    Intent intent = new Intent();
                                    intent.setAction(
                                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                    Uri uri = Uri.fromParts("package",
                                            BuildConfig.APPLICATION_ID, null);
                                    intent.setData(uri);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(intent);
                                }
                            });
                }
            }
        }
        @Override
        public void onResume() {
            super.onResume();

            if(getView() == null){
                return;
            }

            getView().setFocusableInTouchMode(true);
            getView().requestFocus();
            getView().setOnKeyListener(new View.OnKeyListener() {
                @Override
                public boolean onKey(View v, int keyCode, KeyEvent event) {

                    if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK){
                        MenuKurir mainHomeFragment = new MenuKurir();
                        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
                        fragmentTransaction.replace(R.id.FrameKurir, mainHomeFragment);
                        fragmentTransaction.commit();


                        return true;

                    }
                    return false;
                }
            });
        }

        private void initDataIntent(final Spbu spbu) {
            recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(), new RecyclerItemClickListener.OnItemClickListener() {
                @Override
                public void onItemClick(View view, int position) {

                    String alamat = spbu.getData().get(position).getAlamat();
                    String lat=String.valueOf(spbu.getData().get(position).getLat());
                    String lang= String.valueOf(spbu.getData().get(position).getLang());



                    Bundle detailpesanan = new Bundle();

                    detailpesanan.putString(Constant.KEY_SpbuAlamat, alamat);
                    detailpesanan.putString(Constant.KEY_SpbuLat, lat);
                    detailpesanan.putString(Constant.KEY_SpbuLang, lang);
                    DetailSpbu fragment = new DetailSpbu();
                    fragment.setArguments(detailpesanan);
                    getFragmentManager()
                            .beginTransaction()
                            .replace(R.id.FrameKurir, fragment)
                            .commit();


                }
            }));
        }

        private void showDialog() {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());

            // set title dialog
            alertDialogBuilder.setTitle("Halo brooooo?");

            // set pesan dari dialog
            alertDialogBuilder.setMessage("Tidak Ada Data......!").setIcon(R.mipmap.ic_launcher)

                    .setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuKurir()).commit();
                        }
                    });


            // membuat alert dialog dari builder
            AlertDialog alertDialog = alertDialogBuilder.create();

            // menampilkan alert dialog
            alertDialog.show();
        }

        public void fetchSpbu() {
            User user = PrefUtil.getUser(getActivity(), PrefUtil.USER_SESSION);


            getservice = new getSpbuService(getActivity());
            getservice.doGetSpbu(lat, lang, new Callback() {

                @Override
                public void onResponse(Call call, Response response) {
                    progressBar.setVisibility(View.GONE);
                    Spbu spbu = (Spbu) response.body();
                    try {
                        if (spbu.getCode() == 1) {
                            adapter = new SpbuAdapter(spbu, getActivity());
                            recyclerView.setAdapter(adapter);
                            adapter.notifyDataSetChanged();

                            initDataIntent(spbu);
                        } else {

                            Toast.makeText(getActivity(), spbu.getMessage(), Toast.LENGTH_LONG).show();
                            getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuKurir()).commit();
                        }
                    }catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(Call call, Throwable t) {

                    progressBar.setVisibility(View.GONE);

                }
            });
        }



    }
