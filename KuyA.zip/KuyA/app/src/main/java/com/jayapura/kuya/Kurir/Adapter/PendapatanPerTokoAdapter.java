package com.jayapura.kuya.Kurir.Adapter;



import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.jayapura.kuya.Model.Pesanan;
import com.jayapura.kuya.R;

import java.text.NumberFormat;
import java.util.Locale;


/**
 * Created by hasan on 17/08/18.
 */

public class PendapatanPerTokoAdapter extends RecyclerView.Adapter<PendapatanPerTokoAdapter .MyViewHolder> {

    private Pesanan pesanan;

    private Context context;


    public PendapatanPerTokoAdapter (Pesanan pesanan, Context context) {
        this.pesanan = pesanan;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pesanan_item_selesai_kurir, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.txtNama.setText(pesanan.getData().get(position).getNama_pelanggan());
        holder.txtAlamat.setText(pesanan.getData().get(position).getAlamat_pelanggan());
        holder.txtNoPesanan.setText("No. Pesanan : " + pesanan.getData().get(position).getNo_pesan());
        double harga=Double.parseDouble(pesanan.getData().get(position).getHarga());
        double ongkir=Double.parseDouble(pesanan.getData().get(position).getOngkir());
        Locale localeID = new Locale("in", "ID");
        NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(localeID);
        holder.txtHarga.setText("Harga: " + formatRupiah.format((double) harga)+" "+ "Ongkir:" + formatRupiah.format((double) ongkir));



    }

    @Override
    public int getItemCount() {
        return pesanan.getData().size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView txtNama,txtAlamat,txtNoPesanan,txtHarga;

        public MyViewHolder(View itemView) {
            super(itemView);
            txtNama= itemView.findViewById(R.id.txtNama);
            txtAlamat = itemView.findViewById(R.id.txtAlamat);
            txtNoPesanan = itemView.findViewById(R.id.txtNoPesanan);
            txtHarga= itemView.findViewById(R.id.txtHarga);


        }
    }

}


