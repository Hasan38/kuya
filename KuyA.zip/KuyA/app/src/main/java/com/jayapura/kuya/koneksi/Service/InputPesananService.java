package com.jayapura.kuya.koneksi.Service;

import android.content.Context;

import com.jayapura.kuya.koneksi.ApiInterface;
import com.jayapura.kuya.koneksi.RetrofitBuilder;

import retrofit2.Callback;

public class InputPesananService {

    private ApiInterface api;

    public InputPesananService(Context context) {

        api = RetrofitBuilder.builder(context)
                .create(ApiInterface.class);
    }

    public void doInput(String id_kurir, String id_toko,String nama_pelanggan,String tlp_pelanggan1,String tlp_pelanggan2,String jenis_barang,String harga,String ongkir,String alamat_pelanggan, Callback callback) {

        api.InputPesanan(id_kurir,id_toko,nama_pelanggan,tlp_pelanggan1,tlp_pelanggan2,jenis_barang,harga,ongkir,alamat_pelanggan).enqueue(callback);
    }
}
