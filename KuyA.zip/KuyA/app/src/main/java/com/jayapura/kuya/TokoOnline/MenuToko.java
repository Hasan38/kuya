package com.jayapura.kuya.TokoOnline;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.jayapura.kuya.R;
import com.jayapura.kuya.TokoOnline.Kurir.PosisiKurirActivity;
import com.jayapura.kuya.TokoOnline.PendapatanToko.MenuPendapatan;
import com.jayapura.kuya.TokoOnline.PesananToko.MenuPesanan;

public class MenuToko extends Fragment {
    private Button btnPesanan,btnToko,btnPendapatan,btnSpbu,btnKurir;

    @Nullable


    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.dashboard_toko, container, false);
        btnPesanan=view.findViewById(R.id.btnPesanan);
        btnPendapatan=view.findViewById(R.id.btnPendapatan);
        btnSpbu=view.findViewById(R.id.btn_spbu);
        btnToko=view.findViewById(R.id.btn_toko);
        btnKurir=view.findViewById(R.id.btnKurir);




        btnPesanan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getFragmentManager().beginTransaction().replace(R.id.FrameToko, new MenuPesanan()).commit();

            }
        });
        btnPendapatan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getFragmentManager().beginTransaction().replace(R.id.FrameToko, new MenuPendapatan()).commit();

            }
        });
        btnSpbu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getActivity(), " Lagi Dikembangkan ", Toast.LENGTH_LONG).show();

            }
        });
        btnToko.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getActivity(), " Lagi Dikembangkan ", Toast.LENGTH_LONG).show();

            }
        });

        btnKurir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.FrameToko, new PosisiKurirActivity()).commit();


            }
        });

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();


            }



}
