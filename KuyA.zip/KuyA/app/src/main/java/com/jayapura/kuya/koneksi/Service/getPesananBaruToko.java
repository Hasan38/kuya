package com.jayapura.kuya.koneksi.Service;

import android.content.Context;

import com.jayapura.kuya.koneksi.ApiInterface;
import com.jayapura.kuya.koneksi.RetrofitBuilder;

import retrofit2.Callback;

public class getPesananBaruToko {

    private ApiInterface api;

    public getPesananBaruToko(Context context) {

        api = RetrofitBuilder.builder(context)
                .create(ApiInterface.class);
    }

    public void doGetPesananBaru(String id_toko,double lat,double lang, Callback callback) {

        api.getPesananBaru(id_toko,lat,lang).enqueue(callback);
    }
}
