package com.jayapura.kuya.TokoOnline.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class KurirData {

    @SerializedName("nama")
    @Expose
    private String nama;

    @SerializedName("id")
    @Expose
    private String id;

    @SerializedName("lat")
    @Expose
    private double lat;

    @SerializedName("lang")
    @Expose
    private double lang;

    @SerializedName("tgl_update")
    @Expose
    private String tgl_update;

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLang() {
        return lang;
    }

    public void setLang(double lang) {
        this.lang = lang;
    }

    public String getTgl_update() {
        return tgl_update;
    }

    public void setTgl_update(String tgl_update) {
        this.tgl_update = tgl_update;
    }

    public String getWaktu_update() {
        return waktu_update;
    }

    public void setWaktu_update(String waktu_update) {
        this.waktu_update = waktu_update;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    @SerializedName("waktu_update")
    @Expose
    private String waktu_update;

    @SerializedName("img")
    @Expose
    private String img;
}
