package com.jayapura.kuya.koneksi.Service;

import android.content.Context;

import com.jayapura.kuya.koneksi.ApiInterface;
import com.jayapura.kuya.koneksi.RetrofitBuilder;

import retrofit2.Callback;

public class getSetoranService {

    private ApiInterface api;

    public getSetoranService(Context context) {

        api = RetrofitBuilder.builder(context)
                .create(ApiInterface.class);
    }

    public void doGetSetoran(String id_kurir, Callback callback) {

        api.getSetoran(id_kurir).enqueue(callback);
    }
}
