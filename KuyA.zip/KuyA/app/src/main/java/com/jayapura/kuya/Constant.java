package com.jayapura.kuya;
public class Constant {

    /*------------------------------------PesananData------------------------------------------------------*/
    public static final String KEY_PesananNoPesanan= "no_pesan";
    public static final String KEY_PesananAlamatPelanggan = "alamat_pelanggan";
    public static final String KEY_PesananTlp1 ="tlp_pelanggan1" ;
    public static final String KEY_PesananTlp2 = "tlp_pelanggan2";
    public static final String KEY_PesananNamaToko ="nama_toko";
    public static final String KEY_PesananLat ="lat" ;
    public static final String KEY_PesananLang ="lang" ;
    public static final String KEY_PesananTlpToko ="tlp_toko" ;
    public static final String KEY_PesananNamaPelanggan = "nama_pelanggan";
    public static final String KEY_PesananOngkir ="ongkir" ;
    public static final String KEY_PesananHarga ="harga" ;

    /*------------------------------------PesananPendingData------------------------------------------------------*/
    public static final String KEY_PesananPendingNoPesanan= "no_pesan";
    public static final String KEY_PesananPendingAlamatPelanggan = "alamat_pelanggan";
    public static final String KEY_PesananPendingTlp1 ="tlp_pelanggan1" ;
    public static final String KEY_PesananPendingTlp2 = "tlp_pelanggan2";
    public static final String KEY_PesananPendingNamaToko ="nama_toko";
    public static final String KEY_PesananPendingLat ="lat" ;
    public static final String KEY_PesananPendingLang ="lang" ;
    public static final String KEY_PesananPendingTlpToko ="tlp_toko" ;
    public static final String KEY_PesananPendingNamaPelanggan = "nama_pelanggan";
    public static final String KEY_PesananPendingOngkir ="ongkir" ;
    public static final String KEY_PesananPendingHarga ="harga" ;


    /*------------------------------------PesananPendingData------------------------------------------------------*/
    public static final String KEY_PesananCancelNoPesanan= "no_pesan";
    public static final String KEY_PesananCancelAlamatPelanggan = "alamat_pelanggan";
    public static final String KEY_PesananCancelTlp1 ="tlp_pelanggan1" ;
    public static final String KEY_PesananCancelTlp2 = "tlp_pelanggan2";
    public static final String KEY_PesananCancelNamaToko ="nama_toko";

    public static final String KEY_PesananCancelTlpToko ="tlp_toko" ;
    public static final String KEY_PesananCancelNamaPelanggan = "nama_pelanggan";
    public static final String KEY_PesananCancelOngkir ="ongkir" ;
    public static final String KEY_PesananCancelHarga ="harga" ;

    /*------------------------------------PesananAmbilData------------------------------------------------------*/
    public static final String KEY_PesananAmbilNoPesanan= "no_pesan";
    public static final String KEY_PesananAmbilAlamatPelanggan = "alamat_pelanggan";
    public static final String KEY_PesananAmbilTlp1 ="tlp_pelanggan1" ;
    public static final String KEY_PesananAmbilTlp2 = "tlp_pelanggan2";
    public static final String KEY_PesananAmbilNamaToko ="nama_toko";
    public static final String KEY_PesananAmbilJenisBarang ="jenis_barang";
    public static final String KEY_PesananAmbilTlpToko ="tlp_toko" ;
    public static final String KEY_PesananAmbilNamaPelanggan = "nama_pelanggan";
    public static final String KEY_PesananAmbilOngkir ="ongkir" ;
    public static final String KEY_PesananAmbilHarga ="harga" ;

    /*------------------------------------SPBUData------------------------------------------------------*/
    public static final String KEY_SpbuAlamat = "spbu";
    public static final String KEY_SpbuLat = "lat";
    public static final String KEY_SpbuLang ="lang";


    /*------------------------------------PesananData------------------------------------------------------*/

    public static final String KEY_PesananSelesaiNamaToko ="nama_toko";
    public static final String KEY_PesananSelesaiIdToko ="id_toko";
    public static final String KEY_PesananSelesaiOngkir ="ongkir" ;
    public static final String KEY_PesananSelesaiHarga ="harga" ;
    public static final String KEY_PesananSelesaiPaket ="paket" ;

}
