package com.jayapura.kuya.koneksi.Service;

import android.content.Context;

import com.jayapura.kuya.koneksi.ApiInterface;
import com.jayapura.kuya.koneksi.RetrofitBuilder;

import retrofit2.Callback;

public class getPesananPengirimanTokoService {

    private ApiInterface api;

    public getPesananPengirimanTokoService (Context context) {

        api = RetrofitBuilder.builder(context)
                .create(ApiInterface.class);
    }

    public void doGetPesananPengiriman(String id_toko, Callback callback) {

        api.getPengiriman(id_toko).enqueue(callback);
    }
}
