package com.jayapura.kuya.TokoOnline.Kurir;





import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.DrawableRes;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.jayapura.kuya.Model.User;
import com.jayapura.kuya.R;
import com.jayapura.kuya.TokoOnline.MenuToko;
import com.jayapura.kuya.TokoOnline.Model.Kurir;
import com.jayapura.kuya.koneksi.PrefUtil;
import com.jayapura.kuya.koneksi.Service.getPosisiKurirService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;



public class PosisiKurirActivity extends Fragment implements OnMapReadyCallback {
        getPosisiKurirService updatepes;
        private GoogleMap mMap;
        private ProgressDialog progressDialog;
        String nama,id_toko, tlp,tgl_update,waktu_update;
        double lat, lang;
        private TextView Kembali;


        public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            View view = inflater.inflate(R.layout.main_posisi_kurir, container, false);
            Kembali=view.findViewById(R.id.Kembali);

            setUp();
            getposisi();
            setPermisi();

            progressDialog=new ProgressDialog(getActivity());
            Kembali.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    getFragmentManager().beginTransaction().replace(R.id.FrameToko, new MenuToko()).commit();

                }
            });
            return view;
        }

        public void setPermisi() {
            if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                // Permission is not granted
                if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)) {
                    Toast.makeText(getActivity(), "Membutuhkan Izin Lokasi", Toast.LENGTH_SHORT).show();
                } else {

                    // No explanation needed; request the permission
                    ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
                }
            }

        }


        public void setUp() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

                SupportMapFragment mMapFragment;
                mMapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);

                mMapFragment.getMapAsync(this);


                // Call some material design APIs here
            } else {


                SupportMapFragment mMapFragment;
                mMapFragment = (SupportMapFragment) getFragmentManager().findFragmentById(R.id.map);

                mMapFragment.getMapAsync(this);
                // Implement this feature without material design

            }


        }
    private BitmapDescriptor bitmapDescriptorFromVector(Context context, int vectorResId) {
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

        @Override
        public void onResume() {
            super.onResume();

            if (getView() == null) {
                return;
            }

            getView().setFocusableInTouchMode(true);
            getView().requestFocus();
            getView().setOnKeyListener(new View.OnKeyListener() {
                @Override
                public boolean onKey(View v, int keyCode, KeyEvent event) {

                    if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                        MenuToko mainHomeFragment = new MenuToko();
                        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
                        fragmentTransaction.replace(R.id.FrameToko, mainHomeFragment);
                        fragmentTransaction.commit();


                        return true;

                    }
                    return false;
                }
            });
        }




        @Override
        public void onMapReady(GoogleMap googleMap) {
            mMap = googleMap;


            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            mMap.setMyLocationEnabled(true);
        }


        /**
         * method ini digunakan menampilkan data marker dari database
         */
        private void getAllDataLocationLatLng() {

            //set latlng nya
            LatLng location = new LatLng(lat, lang);
            LatLng loc = new LatLng(lat, lang);
            //tambahkan markernya

            mMap.addMarker(new MarkerOptions().position(location)

                    .icon(bitmapDescriptorFromVector(getActivity(), R.drawable.kurir_mk))
                    .title(nama+ " " + tgl_update+ " " + waktu_update));

            //set latlng index ke 0
            LatLng latLng = new LatLng(lat, lang);
            //lalu arahkan zooming ke marker index ke 0
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latLng.latitude, latLng.longitude), 13.0f));
        }

        public void getposisi() {

            User user = PrefUtil.getUser(getActivity(), PrefUtil.USER_SESSION);
            id_toko = user.getData().get(0).getId();
            updatepes = new getPosisiKurirService(getActivity());
            updatepes.doGetPosisi(id_toko, new Callback() {
                @Override
                public void onResponse(Call call, Response response) {
                    Kurir kurir= (Kurir) response.body();
                    progressDialog.dismiss();
                    if (kurir.getCode() == 1) {

                        nama=kurir.getData().get(0).getNama();
                        lat=kurir.getData().get(0).getLat();
                        lang=kurir.getData().get(0).getLang();
                        tgl_update=kurir.getData().get(0).getTgl_update();
                        waktu_update=kurir.getData().get(0).getWaktu_update();
                        getAllDataLocationLatLng();
                    }else{
                        Toast.makeText(getActivity(), kurir.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                }

                @Override
                public void onFailure(Call call, Throwable t) {
                    progressDialog.dismiss();
                }
            });

        }


    }
