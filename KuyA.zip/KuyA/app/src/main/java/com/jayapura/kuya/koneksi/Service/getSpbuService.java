package com.jayapura.kuya.koneksi.Service;

import android.content.Context;

import com.jayapura.kuya.koneksi.ApiInterface;
import com.jayapura.kuya.koneksi.RetrofitBuilder;

import retrofit2.Callback;

public class getSpbuService {


    private ApiInterface api;

    public getSpbuService(Context context) {

        api = RetrofitBuilder.builder(context)
                .create(ApiInterface.class);
    }

    public void doGetSpbu(double lat,double lang, Callback callback) {

        api.getSpbu(lat, lang).enqueue(callback);
    }
}
