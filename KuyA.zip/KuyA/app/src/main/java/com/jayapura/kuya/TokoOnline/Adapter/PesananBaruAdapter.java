package com.jayapura.kuya.TokoOnline.Adapter;


import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.jayapura.kuya.Model.Pesanan;
import com.jayapura.kuya.R;

import java.text.DecimalFormat;


/**
 * Created by hasan on 17/08/18.
 */

public class PesananBaruAdapter extends RecyclerView.Adapter<PesananBaruAdapter .MyViewHolder> {

    private Pesanan pesanan;

    private Context context;
    private String nama_pelanggan,harga,ongkir,tlp_pelanggan1,tlp_pelanggan2,nama_toko;

    public PesananBaruAdapter (Pesanan pesanan, Context context) {
        this.pesanan = pesanan;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pesanan_item_baru_toko, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.txtNama.setText(pesanan.getData().get(position).getNama_pelanggan());
        holder.txtAlamat.setText(pesanan.getData().get(position).getAlamat_pelanggan());
        holder.txtNoPesanan.setText("No. Pesanan : " + pesanan.getData().get(position).getNo_pesan());

        double jarak = Double.parseDouble( pesanan.getData().get(position).getJarak());

        DecimalFormat df = new DecimalFormat("#.##");

        holder.txtJarak.setText(df.format(jarak) +"km");

    }

    @Override
    public int getItemCount() {
        return pesanan.getData().size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView txtNama,txtAlamat,txtJarak,txtNoPesanan;

        public MyViewHolder(View itemView) {
            super(itemView);
            txtNama= itemView.findViewById(R.id.txtNama);
            txtAlamat = itemView.findViewById(R.id.txtAlamat);
            txtJarak=itemView.findViewById(R.id.txtJarak);
            txtNoPesanan=itemView.findViewById(R.id.txtNoPesanan);

        }
    }

}
