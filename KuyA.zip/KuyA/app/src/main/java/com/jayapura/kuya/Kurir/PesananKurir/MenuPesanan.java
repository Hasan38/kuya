package com.jayapura.kuya.Kurir.PesananKurir;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.CardView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.jayapura.kuya.Kurir.MenuKurir;
import com.jayapura.kuya.Kurir.Model.Sum;
import com.jayapura.kuya.Model.User;
import com.jayapura.kuya.R;
import com.jayapura.kuya.koneksi.PrefUtil;
import com.jayapura.kuya.koneksi.Service.getSumPesananKurirService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MenuPesanan extends Fragment {
private CardView btnPengiriman,btnPending,btnCancel,btnAmbil;
private TextView Kembali,txtAmbil,txtPengiriman,txtPending,txtCancel;
getSumPesananKurirService service;
    public MenuPesanan() {
        // Required empty public constructor
    }


    @Nullable
    @SuppressLint("MissingPermission")

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.menu_pesanan_kurir, container, false);

       btnAmbil=view.findViewById(R.id.btn_ambil);
       btnPending=view.findViewById(R.id.btn_pending);
       btnCancel=view.findViewById(R.id.btn_cancel);
       btnPengiriman=view.findViewById(R.id.btn_pengiriman);
       Kembali=view.findViewById(R.id.Kembali);
       txtAmbil=view.findViewById(R.id.txtAmbil);
       txtPending=view.findViewById(R.id.txtPending);
       txtPengiriman=view.findViewById(R.id.txtPengiriman);
       txtCancel=view.findViewById(R.id.txtCancel);


        sum();
        btnPengiriman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new PesananActivityKurir()).commit();


            }
        });

        btnAmbil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new PesananAmbilKurir()).commit();


            }
        });

        btnPending.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new PesananPendingKurir()).commit();


            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new PesananCancelKurir()).commit();


            }
        });

        Kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuKurir()).commit();


            }
        });
        return view;
    }


    @Override
    public void onResume() {
        super.onResume();

        if(getView() == null){
            return;
        }

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK){
                    MenuKurir mainHomeFragment = new MenuKurir();
                    FragmentTransaction fragmentTransaction =
                            getActivity().getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.FrameKurir, mainHomeFragment);
                    fragmentTransaction.commit();


                    return true;

                }
                return false;
            }
        });
    }

    public void sum(){
        String id_kurir;
        User user = PrefUtil.getUser(getActivity(), PrefUtil.USER_SESSION);
        id_kurir = user.getData().get(0).getId();

            service= new getSumPesananKurirService(getActivity());
            service.doGetSum(id_kurir, new Callback() {

                @Override
                public void onResponse(Call call, Response response) {

                    Sum sum = (Sum) response.body();
                    try {
                        if (sum.getCode() == 1) {
                            String Ambil=sum.getData().get(0).getAmbil();
                            String Pengiriman=sum.getData().get(0).getPengiriman();
                            String Pending=sum.getData().get(0).getPending();
                            String Cancel=sum.getData().get(0).getCancel();
                            txtAmbil.setText("Ambil Pesanan "+"("+Ambil+")");
                            txtPengiriman.setText("Pesanan (PENGIRIMAN) "+"("+Pengiriman+")");
                            txtPending.setText("Pesanan (PENDING) "+"("+Pending+")");
                            txtCancel.setText("Pesanan (CANCEL) "+"("+Cancel+")");



                            if(Pengiriman.equals("null")){
                                txtAmbil.setText("0");
                            }else if(Pending.equals("null")){
                                txtPending.setText("0");

                            }else if(Ambil.equals("null")){
                                txtAmbil.setText("0");

                            }else if(Cancel.equals("null")){
                                txtCancel.setText("0");

                            }
                        } else {
                            Toast.makeText(getActivity(), " response message " + response.errorBody().string(), Toast.LENGTH_LONG).show();
                        }
                    }catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(Call call, Throwable t) {


                }
            });
        }


    }

