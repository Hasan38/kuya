package com.jayapura.kuya;


import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import com.felipecsl.gifimageview.library.GifImageView;
import org.apache.commons.io.IOUtils;
import java.io.IOException;
import java.io.InputStream;

public class SplashScreen extends AppCompatActivity {
    private int waktu_loading=3000;
    private GifImageView gift;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splashscreen);
        gift=findViewById(R.id.gif);

        try {
            InputStream input=getAssets().open("loading.gif");
            byte[] bytes= IOUtils.toByteArray(input);
            gift.setBytes(bytes);
            gift.startAnimation();
        } catch (IOException e) {
            e.printStackTrace();
        }



        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                //setelah loading maka akan langsung berpindah ke home activity
                Intent home=new Intent(SplashScreen.this, LoginActivity.class);
                startActivity(home);
                finish();

            }
        },waktu_loading);
    }
}

