package com.jayapura.kuya.koneksi.Service;

import android.content.Context;

import com.jayapura.kuya.koneksi.ApiInterface;
import com.jayapura.kuya.koneksi.RetrofitBuilder;

import retrofit2.Callback;

public class getPesananPendingKurirService {

    private ApiInterface api;

    public getPesananPendingKurirService(Context context) {

        api = RetrofitBuilder.builder(context)
                .create(ApiInterface.class);
    }

    public void doGetPesananPendingKurir(String id_kurir, Callback callback) {

        api.getPesananPending(id_kurir).enqueue(callback);
    }
}
