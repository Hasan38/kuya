package com.jayapura.kuya.Kurir.PesananKurir;



import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.jayapura.kuya.Kurir.Adapter.PesananAmbilKurirAdapter;
import com.jayapura.kuya.Constant;
import com.jayapura.kuya.Model.Pesanan;
import com.jayapura.kuya.Model.User;
import com.jayapura.kuya.R;
import com.jayapura.kuya.RecyclerItemClickListener;
import com.jayapura.kuya.koneksi.PrefUtil;
import com.jayapura.kuya.koneksi.Service.UpdateSemuaPesananKurirService;
import com.jayapura.kuya.koneksi.Service.getPesananAmbilKurirService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PesananAmbilKurir extends Fragment {

    private static final String TAG = PesananActivityKurir.class.getSimpleName();
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;

    private PesananAmbilKurirAdapter adapter;
    private Toolbar toolbarMain;
    String id_kurir;
    private TextView txtPaket;

    ProgressBar progressBar;
    getPesananAmbilKurirService getservice;
    UpdateSemuaPesananKurirService updateservice;
    private ProgressDialog progressDialog;

    private boolean adaInternet(){
        ConnectivityManager koneksi = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        return koneksi.getActiveNetworkInfo() != null;
    }

    public PesananAmbilKurir() {
        // Required empty public constructor
    }


    @Nullable
    @SuppressLint("MissingPermission")

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.baris_pesanan_ambil_kurir, container, false);


        txtPaket=view.findViewById(R.id.txtPaket);
        TextView Kembali=view.findViewById(R.id.Kembali);
        TextView AmbilSemua=view.findViewById(R.id.AmbilSemua);




        progressBar = view.findViewById(R.id.prograss);
        recyclerView = view.findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        progressDialog = new ProgressDialog(getActivity());

        Kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuPesanan()).commit();
            }
        });

        AmbilSemua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO something when floating action menu second item clicked
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage("Apakah Ingin Ambil Semua")
                        .setPositiveButton("Ambil", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                progressDialog.setTitle("KUYA");
                                progressDialog.setMessage("Loading ...");
                                progressDialog.show();
                                User user = PrefUtil.getUser(getActivity(), PrefUtil.USER_SESSION);
                                String id_kurir = user.getData().get(0).getId();
                                String status_pesan="Ambil";

                                updateservice = new UpdateSemuaPesananKurirService(getActivity());
                                updateservice.doUpdate(id_kurir,status_pesan, new Callback(){

                                    @Override
                                    public void onResponse(Call call, Response  response) {
                                        if(adaInternet()){

                                            Pesanan pesanan=(Pesanan)response.body();
                                        if (pesanan.getCode()==1) {
                                         getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuPesanan()).commit();
                                         Toast.makeText(getActivity(), pesanan.getMessage(), Toast.LENGTH_SHORT).show();
                                        }else{
                                            getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuPesanan()).commit();
                                            }
                                        }

                                        progressDialog.dismiss();
                                    }



                                    @Override
                                    public void onFailure(Call call, Throwable t) {
                                        t.printStackTrace();
                                        Toast.makeText(getActivity(), "Jaringan Error!", Toast.LENGTH_SHORT).show();
                                        progressDialog.dismiss();


                                    }
                                });

                            }
                        }).setCancelable(true).setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();

            }


        });




        fetchPrestasi();

        final SwipeRefreshLayout dorefresh = view.findViewById(R.id.swipeRefresh);
        dorefresh.setColorSchemeResources(android.R.color.holo_blue_bright, android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_red_light);

        /*event ketika widget dijalankan*/
        dorefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refreshItem();
            }

            void refreshItem() {
                fetchPrestasi();
                onItemLoad();
            }

            void onItemLoad() {
                dorefresh.setRefreshing(false);
            }

        });


        return view;
    }




    @Override
    public void onResume() {
        super.onResume();

        if(getView() == null){
            return;
        }

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK){
                    MenuPesanan mainHomeFragment = new MenuPesanan();
                    FragmentTransaction fragmentTransaction =
                            getActivity().getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.FrameKurir, mainHomeFragment);
                    fragmentTransaction.commit();


                    return true;

                }
                return false;
            }
        });
    }

    private void initDataIntent(final Pesanan pesanan) {
        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(), new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                String no_pesan = pesanan.getData().get(position).getNo_pesan();
                String alamat_pelanggan = pesanan.getData().get(position).getAlamat_pelanggan();
                String tlp_pelanggan1 = pesanan.getData().get(position).getTlp_pelanggan1();
                String tlp_pelanggan2= pesanan.getData().get(position).getTlp_pelanggan2();
                String nama_toko = pesanan.getData().get(position).getNama_toko();
                String ongkir=pesanan.getData().get(position).getOngkir();
                String jenis_barang=pesanan.getData().get(position).getJenis_barang();
                String harga=pesanan.getData().get(position).getHarga();
                String tlp_toko= pesanan.getData().get(position).getTlp_toko();
                String nama_pelanggan=pesanan.getData().get(position).getNama_pelanggan();


                Bundle detailpesanan = new Bundle();
                detailpesanan.putString(Constant.KEY_PesananAmbilNoPesanan, no_pesan);
                detailpesanan.putString(Constant.KEY_PesananAmbilAlamatPelanggan, alamat_pelanggan);
                detailpesanan.putString(Constant.KEY_PesananAmbilTlp1, tlp_pelanggan1);
                detailpesanan.putString(Constant.KEY_PesananAmbilTlp2, tlp_pelanggan2);
                detailpesanan.putString(Constant.KEY_PesananAmbilJenisBarang, jenis_barang);
                detailpesanan.putString(Constant.KEY_PesananAmbilNamaToko, nama_toko);
                detailpesanan.putString(Constant.KEY_PesananAmbilOngkir,ongkir);
                detailpesanan.putString(Constant.KEY_PesananAmbilHarga,harga);

                detailpesanan.putString(Constant.KEY_PesananAmbilTlpToko, tlp_toko);
                detailpesanan.putString(Constant.KEY_PesananAmbilNamaPelanggan, nama_pelanggan);

                DetailPesananAmbilKurir fragment = new DetailPesananAmbilKurir();
                fragment.setArguments(detailpesanan);

                getFragmentManager()
                        .beginTransaction()
                        .replace(R.id.FrameKurir, fragment)
                        .commit();


            }
        }));
    }

    private void showDialog() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());

        // set title dialog
        alertDialogBuilder.setTitle("Halo brooooo?");

        // set pesan dari dialog
        alertDialogBuilder.setMessage("Tidak Ada Data......!").setIcon(R.mipmap.ic_launcher)

                .setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuPesanan()).commit();
                    }
                });


        // membuat alert dialog dari builder
        AlertDialog alertDialog = alertDialogBuilder.create();

        // menampilkan alert dialog
        alertDialog.show();
    }

    public void fetchPrestasi() {
        User user = PrefUtil.getUser(getActivity(), PrefUtil.USER_SESSION);
        id_kurir = user.getData().get(0).getId();

        getservice = new getPesananAmbilKurirService(getActivity());
        getservice.doGetPesananAmbilKurir(id_kurir, new Callback() {

            @Override
            public void onResponse(Call call, Response response) {
                progressBar.setVisibility(View.GONE);
                Pesanan pesanan = (Pesanan) response.body();
                try {
                    if (pesanan.getCode() == 1) {
                        adapter = new PesananAmbilKurirAdapter(pesanan, getActivity());
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();
                        txtPaket.setText("Jumlah: "+pesanan.getPaket()+" Paket");
                        initDataIntent(pesanan);
                    } else {

                        getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuPesanan()).commit();
                    }
                }catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call call, Throwable t) {

                progressBar.setVisibility(View.GONE);

            }
        });
    }


}