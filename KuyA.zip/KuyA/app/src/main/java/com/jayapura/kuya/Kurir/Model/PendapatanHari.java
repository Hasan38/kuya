package com.jayapura.kuya.Kurir.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PendapatanHari { @SerializedName("data")
@Expose
private List<PendapatanHariData> data = null;
    @SerializedName("code")
    @Expose
    private Integer code;
    @SerializedName("message")
    @Expose
    private String message;

    public String getPaket() {
        return paket;
    }

    public void setPaket(String paket) {
        this.paket = paket;
    }

    @SerializedName("paket")
    @Expose
    private String paket;

    public List<PendapatanHariData>getData() {
        return data;
    }

    public void setData(List<PendapatanHariData>data) {
        this.data = data;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
