package com.jayapura.kuya.koneksi.Service;

import android.content.Context;

import com.jayapura.kuya.koneksi.ApiInterface;
import com.jayapura.kuya.koneksi.RetrofitBuilder;

import retrofit2.Callback;

public class getKecamatanService {
    private ApiInterface api;

    public  getKecamatanService (Context context) {

        api = RetrofitBuilder.builder(context)
                .create(ApiInterface.class);
    }

    public void doGetKec(String id, Callback callback) {

        api.getKec(id).enqueue(callback);
    }
}
