package com.jayapura.kuya.Kurir.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.jayapura.kuya.Kurir.Model.Toko;
import com.jayapura.kuya.R;


/**
 * Created by hasan on 17/08/18.
 */

public class TokoAdapter extends RecyclerView.Adapter<TokoAdapter.MyViewHolder> {

    private Toko toko;

    private Context context;


    public TokoAdapter(Toko toko, Context context) {
        this.toko= toko;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.toko_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        holder.txtAlamat.setText(toko.getData().get(position).getAlamat());
        holder.txtNamaToko.setText(toko.getData().get(position).getNama_toko());
        holder.txtTlp.setText(toko.getData().get(position).getTlp());




    }

    @Override
    public int getItemCount() {
        return toko.getData().size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView txtAlamat,txtTlp,txtNamaToko;

        public MyViewHolder(View itemView) {
            super(itemView);
            txtAlamat = itemView.findViewById(R.id.txtAlamat);
            txtNamaToko=itemView.findViewById(R.id.txtNamaToko);
            txtTlp=itemView.findViewById(R.id.txtTlp);

        }
    }

}
