package com.jayapura.kuya.koneksi.Service;

import android.content.Context;

import com.jayapura.kuya.koneksi.ApiInterface;
import com.jayapura.kuya.koneksi.RetrofitBuilder;

import retrofit2.Callback;

public class LoginService {
    private ApiInterface api;

    public  LoginService(Context context) {

        api = RetrofitBuilder.builder(context)
                .create(ApiInterface.class);
    }

    public void doLogin(String email, String password, Callback callback) {

        api.login(email,password).enqueue(callback);
    }
}
