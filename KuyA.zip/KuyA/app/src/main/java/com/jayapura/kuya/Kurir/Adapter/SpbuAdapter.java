package com.jayapura.kuya.Kurir.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.jayapura.kuya.Kurir.Model.Spbu;
import com.jayapura.kuya.R;

import java.text.DecimalFormat;


/**
 * Created by hasan on 17/08/18.
 */

public class SpbuAdapter extends RecyclerView.Adapter<SpbuAdapter.MyViewHolder> {

    private Spbu spbu;

    private Context context;
    private String nama_pelanggan,harga,ongkir,tlp_pelanggan1,tlp_pelanggan2,nama_toko;

    public SpbuAdapter(Spbu spbu, Context context) {
        this.spbu = spbu;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.spbu_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        holder.txtAlamat.setText(spbu.getData().get(position).getAlamat());


        double jarak = Double.parseDouble( spbu.getData().get(position).getJarak());

        DecimalFormat df = new DecimalFormat("#.##");

        holder.txtJarak.setText(df.format(jarak) +"km");

    }

    @Override
    public int getItemCount() {
        return spbu.getData().size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView txtAlamat,txtJarak;

        public MyViewHolder(View itemView) {
            super(itemView);
            txtAlamat = itemView.findViewById(R.id.txtAlamat);
            txtJarak=itemView.findViewById(R.id.txtJarak);

        }
    }

}
