package com.jayapura.kuya.Kurir.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SpbuData {

    @SerializedName("id")
    @Expose
    private Integer id;

    @SerializedName("alamat")
    @Expose
    private String alamat;

    @SerializedName("lat")
    @Expose
    private double lat;

    public String getJarak() {
        return jarak;
    }

    public void setJarak(String jarak) {
        this.jarak = jarak;
    }

    @SerializedName("jarak")
    @Expose
    private String jarak;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLang() {
        return lang;
    }

    public void setLang(double lang) {
        this.lang = lang;
    }

    @SerializedName("lang")
    @Expose
    private double lang;
}
