package com.jayapura.kuya.Kurir.PendapatanKurir;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.jayapura.kuya.Kurir.Adapter.PendapatanPerTokoAdapter;
import com.jayapura.kuya.Constant;
import com.jayapura.kuya.Model.Pesanan;
import com.jayapura.kuya.Model.User;
import com.jayapura.kuya.R;
import com.jayapura.kuya.koneksi.PrefUtil;
import com.jayapura.kuya.koneksi.Service.getPendapatanKurirTokoService;

import java.text.NumberFormat;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PendapatanPerTokoKurir extends Fragment {


    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;

    private PendapatanPerTokoAdapter adapter;
    String id_kurir,id_toko,harga,ongkir,paket,nama_toko;
    private TextView txtPaket,txtHarga,txtOngkir;
    ProgressBar progressBar;
    getPendapatanKurirTokoService getservice;

    public PendapatanPerTokoKurir() {
        // Required empty public constructor
    }


    @Nullable
    @SuppressLint("MissingPermission")

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.baris_pendapatan_h_kurir, container, false);


        txtPaket=view.findViewById(R.id.txtPaket);


        TextView Kembali=view.findViewById(R.id.Kembali);




        progressBar = view.findViewById(R.id.prograss);
        recyclerView = view.findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);


        Kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuPendapatan()).commit();
            }
        });


        Bundle bundle = this.getArguments();

        id_toko = bundle.getString(Constant.KEY_PesananSelesaiIdToko);
        nama_toko = bundle.getString(Constant.KEY_PesananSelesaiNamaToko);
        harga=bundle.getString(Constant.KEY_PesananSelesaiHarga);
        ongkir = bundle.getString(Constant.KEY_PesananSelesaiOngkir);
        paket = bundle.getString(Constant.KEY_PesananSelesaiPaket);

        double harga1=Double.parseDouble(harga);
        double ongkir1=Double.parseDouble(ongkir);
        Locale localeID = new Locale("in", "ID");
        NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(localeID);


        txtPaket.setText("Paket: " + paket + " " + "Harga: " + formatRupiah.format((double) harga1)+" "+ "Ongkir: "+ formatRupiah.format((double) ongkir1));
        fetchPrestasi();

        final SwipeRefreshLayout dorefresh = view.findViewById(R.id.swipeRefresh);
        dorefresh.setColorSchemeResources(android.R.color.holo_blue_bright, android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_red_light);

        /*event ketika widget dijalankan*/
        dorefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refreshItem();
            }

            void refreshItem() {
                fetchPrestasi();
                onItemLoad();
            }

            void onItemLoad() {
                dorefresh.setRefreshing(false);
            }

        });


        return view;
    }

    @Override
    public void onResume() {
        super.onResume();

        if(getView() == null){
            return;
        }

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK){
                    MenuPendapatan mainHomeFragment = new MenuPendapatan();
                    FragmentTransaction fragmentTransaction =
                            getActivity().getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.FrameKurir, mainHomeFragment);
                    fragmentTransaction.commit();


                    return true;

                }
                return false;
            }
        });
    }



    private void showDialog() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());

        // set title dialog
        alertDialogBuilder.setTitle("Halo brooooo?");

        // set pesan dari dialog
        alertDialogBuilder.setMessage("Tidak Ada Data......!").setIcon(R.mipmap.ic_launcher)

                .setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuPendapatan()).commit();
                    }
                });


        // membuat alert dialog dari builder
        AlertDialog alertDialog = alertDialogBuilder.create();

        // menampilkan alert dialog
        alertDialog.show();
    }

    public void fetchPrestasi() {
        User user = PrefUtil.getUser(getActivity(), PrefUtil.USER_SESSION);
        id_kurir = user.getData().get(0).getId();

        getservice = new getPendapatanKurirTokoService(getActivity());
        getservice.doGetPesananKurirToko(id_kurir, id_toko, new Callback() {

            @Override
            public void onResponse(Call call, Response response) {
                progressBar.setVisibility(View.GONE);
                Pesanan pesanan = (Pesanan) response.body();
                try {
                    if (pesanan.getCode() == 1) {
                        adapter = new PendapatanPerTokoAdapter(pesanan, getActivity());
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();


                    } else {

                        Toast.makeText(getActivity(), pesanan.getMessage(), Toast.LENGTH_LONG).show();
                        getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuPendapatan()).commit();
                    }
                }catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call call, Throwable t) {

                progressBar.setVisibility(View.GONE);

            }
        });
    }


}