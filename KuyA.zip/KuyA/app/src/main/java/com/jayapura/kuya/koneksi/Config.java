package com.jayapura.kuya.koneksi;


public class Config {
    public static final String API ="http://esiap.org/";

    public static final String API_LOGIN = API + "login.php";
    public static final String REGISTER=API+"register.php";
    public static final String GET_KABUPATEN= API + "getkabupaten.php";
    public static final String GET_KECAMATAN= API + "getkecamatan.php";

    /*----------------------------------------------------------------------------------------------------*/

    public static final String API_URL ="http://esiap.org/kurir/";


    public static final String GET_PESANAN= API_URL + "getpesananpengiriman.php";
    public static final String UPDATE_PESANAN= API_URL + "updatepesanan.php";
    public static final String SUM_PESANAN= API_URL + "getsumpesanankurir.php";
    public static final String GET_PESANAN_PENDING_KURIR= API_URL + "getpesananpending.php";
    public static final String GET_PESANAN_CANCEL_KURIR= API_URL + "getpesanancancel.php";
    public static final String GET_PESANAN_AMBIL_KURIR= API_URL + "getpesananambil.php";
    public static final String UPDATE_SEMUA_PESANAN_AMBIL_KURIR= API_URL + "ambilsemuapesanan.php";
    public static final String GET_PENDAPATAN_HARI_KURIR= API_URL + "pendapatankurirperhari.php";
    public static final String GET_SETORAN= API_URL + "setoran.php";
    public static final String GET_SPBU= API_URL + "getspbu.php";
    public static final String GET_TOKO= API_URL + "gettoko.php";
    public static final String GET_PESANAN_SELESAI= API_URL + "getpesananselesai.php";
    public static final String UPDATE_LOKASI= API_URL + "updatelokasi.php";



    /*----------------------------------------------------------------------------------------------------*/

    public static final String API_TOKO ="http://esiap.org/toko/";

    public static final String GET_PESANAN_BARU= API_TOKO + "getpesanantoko.php";
    public static final String GET_KURIR= API_TOKO + "getkurir.php";
    public static final String INPUT_PESANAN= API_TOKO + "inputpesanan.php";
    public static final String POSISI_KURIR= API_TOKO + "getposisikurir.php";
    public static final String GET_PESANAN_PENGIRIMAN_TOKO= API_TOKO + "getpesananpengiriman.php";
    public static final String SUM_PESANAN_TOKO= API_TOKO + "getsumpesanantoko.php";
    public static final String GET_SETORAN_TOKO= API_TOKO + "setoran.php";
    public static final String GET_PENDAPATAN_HARI_TOKO= API_TOKO + "getpendapatantokoperhari.php";
    public static final String GET_PESANAN_SELESAI_TOKO= API_TOKO + "getpesananselesai.php";
}
