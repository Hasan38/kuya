package com.jayapura.kuya.Kurir.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PendapatanHariData {

    @SerializedName("setor")
    @Expose
    private String setor;

    @SerializedName("ongkir")
    @Expose
    private String ongkir;

    public String getPaket() {
        return paket;
    }

    public void setPaket(String paket) {
        this.paket = paket;
    }

    @SerializedName("paket")
    @Expose
    private String paket;

    public String getSetor() {
        return setor;
    }

    public void setSetor(String setor) {
        this.setor = setor;
    }

    public String getOngkir() {
        return ongkir;
    }

    public void setOngkir(String ongkir) {
        this.ongkir = ongkir;
    }

    public String getTgl_update() {
        return tgl_update;
    }

    public void setTgl_update(String tgl_update) {
        this.tgl_update = tgl_update;
    }

    @SerializedName("tgl_update")
    @Expose
    private String tgl_update;
}
