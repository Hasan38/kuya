package com.jayapura.kuya.koneksi;

import com.jayapura.kuya.Model.Kabupaten;
import com.jayapura.kuya.Model.Kecamatan;
import com.jayapura.kuya.Kurir.Model.PendapatanHari;
import com.jayapura.kuya.Model.Pesanan;
import com.jayapura.kuya.Kurir.Model.Setoran;
import com.jayapura.kuya.Kurir.Model.Spbu;
import com.jayapura.kuya.Kurir.Model.Sum;
import com.jayapura.kuya.Kurir.Model.Toko;
import com.jayapura.kuya.Model.User;
import com.jayapura.kuya.TokoOnline.Model.Kurir;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiInterface {


    /* ------------------------------------------------------------------------*/

    @GET(Config.GET_KABUPATEN)
    Call<Kabupaten> getKab();

    /* ------------------------------------------------------------------------*/
    @GET(Config.GET_KECAMATAN)
    Call<Kecamatan> getKec(
            @Query("id") String id
    );


    /* ------------------------------------------------------------------------*/
    @FormUrlEncoded
    @POST(Config.REGISTER)
    Call<User> register(
            @Field("nama_toko") String nama_toko,
            @Field("nama") String nama,
            @Field("alamat") String alamat,
            @Field("tlp") String tlp,
            @Field("kecamatan") String kecamatan,
            @Field("kabupaten") String kabupaten,
            @Field("lat") double lat,
            @Field("lang") double lang,
            @Field("usertype") String usertype,
            @Field("email") String email,
            @Field("password") String password
            );


    /*-------------------------------------------------------------------------- */

    @FormUrlEncoded
    @POST(Config.API_LOGIN)
    Call<User> login(
            @Field("email") String email,
            @Field("password") String password
    );


    /*--------------------------------------------------------------------- */

    @GET(Config.GET_PESANAN)
    Call<Pesanan> getPesanan(
            @Query("id_kurir") String id_kurir,
            @Query("lat") double lat,
            @Query("lang") double lang

    );


    /* ------------------------------------------------------------------------*/

    @GET(Config.UPDATE_PESANAN)
    Call<Pesanan> updatePesanan(
            @Query("no_pesan") String no_pesan,
            @Query("status_pesanan") String status_pesanan
    );


    /* ------------------------------------------------------------------------*/
    @GET(Config.SUM_PESANAN)
    Call<Sum> getSum(
            @Query("id_kurir") String id_kurir


    );


    /* ------------------------------------------------------------------------*/
    @GET(Config.GET_PESANAN_PENDING_KURIR)
    Call<Pesanan> getPesananPending(
            @Query("id_kurir") String id_kurir


    );
    /* ------------------------------------------------------------------------*/
    @GET(Config.GET_PESANAN_CANCEL_KURIR)
    Call<Pesanan> getPesananCancel(
            @Query("id_kurir") String id_kurir


    );
    /* ------------------------------------------------------------------------*/
    @GET(Config.GET_PESANAN_AMBIL_KURIR)
    Call<Pesanan> getPesananAmbil(
            @Query("id_kurir") String id_kurir


    );
    /* ------------------------------------------------------------------------*/
    @FormUrlEncoded
    @POST(Config.UPDATE_SEMUA_PESANAN_AMBIL_KURIR)
    Call<Pesanan> updateSemuaPesanan(
            @Field("id_kurir") String id_kurir,
            @Field("status_pesanan") String status_pesanan
    );

    /* ------------------------------------------------------------------------*/


    @GET(Config.GET_PENDAPATAN_HARI_KURIR)
    Call<PendapatanHari> getPendapatanHari(
            @Query("id_kurir") String id_kurir
    );

    /* ------------------------------------------------------------------------*/


    @GET(Config.GET_SETORAN)
    Call<Setoran> getSetoran(
            @Query("id_kurir") String id_kurir
    );


    /* ------------------------------------------------------------------------*/

    @GET(Config.GET_SPBU)
    Call<Spbu> getSpbu(
            @Query("lat") double lat,
            @Query("lang") double lang
    );


    /* ------------------------------------------------------------------------*/

    @GET(Config.GET_TOKO)
    Call<Toko> getToko(

    );


    /* ------------------------------------------------------------------------*/

    @GET(Config.GET_PESANAN_SELESAI)
    Call<Pesanan> getPesananSelesai(
            @Query("id_kurir") String id_kurir,
            @Query("id_toko") String id_toko
    );


    @GET(Config.UPDATE_LOKASI)
    Call<User> getUpdate(
            @Query("id_kurir") String id_kurir,
            @Query("lat") double lat,
            @Query("lang") double lang
    );


    /* ------------------------------------------------------------------------*/
    /* ------------------------------------------------------------------------*/
    /* ----------------------------------API TOKO--------------------------------------*/


    @GET(Config.GET_PESANAN_BARU)
    Call<Pesanan> getPesananBaru(

            @Query("id_toko") String id_toko,
            @Query("lat") double lat,
            @Query("lang") double lang
    );

    @GET(Config.GET_KURIR)
    Call<Toko> getKurir(

    );

    /* ------------------------------------------------------------------------*/

    @FormUrlEncoded
    @POST(Config.INPUT_PESANAN)
    Call<Pesanan> InputPesanan(
            @Field("id_kurir") String id_kurir,
            @Field("id_toko") String id_toko,
            @Field("nama_pelanggan") String nama_pelanggan,
            @Field("tlp_pelanggan1") String tlp_pelanggan1,
            @Field("tlp_pelanggan2") String tlp_pelanggan2,
            @Field("jenis_barang") String jenis_barang,
            @Field("harga") String harga,
            @Field("ongkir") String ongkir,
            @Field("alamat_pelanggan") String alamat_pelanggan

    );


    /*-------------------------------------------------------------------------- */
    @GET(Config.POSISI_KURIR)
    Call<Kurir> getPosisi(
            @Query("id_toko") String id_toko

    );

    /* ------------------------------------------------------------------------*/
    @GET(Config.GET_PESANAN_PENGIRIMAN_TOKO)
    Call<Pesanan> getPengiriman(
            @Query("id_toko") String id_toko

    );

    /* ------------------------------------------------------------------------*/
    @GET(Config.SUM_PESANAN_TOKO)
    Call<Sum> getSumToko(
            @Query("id_toko") String id_kurir


    );
    /* ------------------------------------------------------------------------*/

    @GET(Config.GET_SETORAN_TOKO)
    Call<Setoran> getSetoranToko(
            @Query("id_toko") String id_toko
    );
    /* ------------------------------------------------------------------------*/

    @GET(Config.GET_PENDAPATAN_HARI_TOKO)
    Call<PendapatanHari> getPendapatanHariToko(
            @Query("id_toko") String id_toko
    );

    /* ------------------------------------------------------------------------*/

    @GET(Config.GET_PESANAN_SELESAI_TOKO)
    Call<Pesanan> getPesananSelesai(
            @Query("id_toko") String id_toko

    );
}
