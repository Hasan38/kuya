package com.jayapura.kuya.koneksi.Service;

import android.content.Context;

import com.jayapura.kuya.koneksi.ApiInterface;
import com.jayapura.kuya.koneksi.RetrofitBuilder;

import retrofit2.Callback;

public class getPesananCancelKurirService {
    private ApiInterface api;

    public getPesananCancelKurirService (Context context) {

        api = RetrofitBuilder.builder(context)
                .create(ApiInterface.class);
    }

    public void doGetPesananCancelKurir(String id_kurir, Callback callback) {

        api.getPesananCancel(id_kurir).enqueue(callback);
    }
}
