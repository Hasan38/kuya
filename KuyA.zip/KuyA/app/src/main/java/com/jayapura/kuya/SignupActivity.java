package com.jayapura.kuya;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.jayapura.kuya.Model.Kabupaten;
import com.jayapura.kuya.Model.Kecamatan;
import com.jayapura.kuya.Model.User;
import com.jayapura.kuya.koneksi.Service.RegisterService;
import com.jayapura.kuya.koneksi.Service.getKabupatenService;
import com.jayapura.kuya.koneksi.Service.getKecamatanService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SignupActivity extends AppCompatActivity {
    private static final String TAG = "SignupActivity";
    private EditText _nameText,_namaToko, _addressText, _emailText, _mobileText, _passwordText, _reEnterPasswordText;
    private Button _signupButton;
    private TextView _loginLink;
    private List<String> listSpinner;
    private Spinner spnUsertype, spnKecamatan, spnKabupaten;
    getKabupatenService getkabservice;
    getKecamatanService getkecservice;
    RegisterService registerService;
    private List<String> listSpinnerKab;
    private List<String> listSpinnerKab1;
    private List<String> listSpinnerKec;
    private List<String> listSpinnerKec1;
    private double lat;
    private double lang;
    private Kabupaten kab;
    private TextInputLayout TextToko;
    private static final int REQUEST_PERMISSIONS_REQUEST_CODE = 34;
    private FusedLocationProviderClient mFusedLocationClient;
    private String id_kab,id_kec;

    protected Location mLastLocation;

    @SuppressLint("MissingPermission")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup_activity);
        _nameText = findViewById(R.id.input_name);
        _addressText = findViewById(R.id.input_address);
        _emailText = findViewById(R.id.input_email);
        _mobileText = findViewById(R.id.input_mobile);
        _passwordText = findViewById(R.id.input_password);
        _reEnterPasswordText = findViewById(R.id.input_reEnterPassword);
        _signupButton = findViewById(R.id.btn_signup);
        _loginLink = findViewById(R.id.link_login);
        spnUsertype = findViewById(R.id.spnUsertye);
        spnKecamatan = findViewById(R.id.spnKecamatan);
        spnKabupaten = findViewById(R.id.spnKabupaten);
        TextToko=findViewById(R.id.TextToko);
        _namaToko=findViewById(R.id.nama_toko);


        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        _signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signup();
            }
        });

        getKab();
        SpnKab();

        aturmenu();


        String[] jkArray = getResources().getStringArray(R.array.usertype);
        listSpinner = Arrays.asList(jkArray);
        spnUsertype.setAdapter(new MyCustomAdapter(SignupActivity.this, R.layout.row, listSpinner));

        _loginLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Finish the registration screen and return to the Login activity
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                finish();
                overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
            }
        });
    }
    @Override
    public void onStart() {
        super.onStart();

        if (!checkPermissions()) {
            requestPermissions();
        } else {
            getLastLocation();
        }
    }


    @SuppressWarnings("MissingPermission")
    private void getLastLocation() {
        mFusedLocationClient.getLastLocation()
                .addOnCompleteListener(this, new OnCompleteListener<Location>() {
                    @Override
                    public void onComplete(@NonNull Task<Location> task) {
                        if (task.isSuccessful() && task.getResult() != null) {
                            mLastLocation = task.getResult();
lat=mLastLocation.getLatitude();
lang=mLastLocation.getLongitude();

                        } else {
                            Log.w(TAG, "getLastLocation:exception", task.getException());

                        }
                    }
                });
    }
    private boolean checkPermissions() {
        int permissionState = ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION);
        return permissionState == PackageManager.PERMISSION_GRANTED;
    }
    private void showSnackbar(final int mainTextStringId, final int actionStringId,
                              View.OnClickListener listener) {
        Snackbar.make(findViewById(android.R.id.content),
                getString(mainTextStringId),
                Snackbar.LENGTH_INDEFINITE)
                .setAction(getString(actionStringId), listener).show();
    }
    private void startLocationPermissionRequest() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                REQUEST_PERMISSIONS_REQUEST_CODE);
    }

    private void requestPermissions() {
        boolean shouldProvideRationale =
                ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.ACCESS_COARSE_LOCATION);

        // Provide an additional rationale to the user. This would happen if the user denied the
        // request previously, but didn't check the "Don't ask again" checkbox.
        if (shouldProvideRationale) {
            Log.i(TAG, "Displaying permission rationale to provide additional context.");

            showSnackbar(R.string.permission_rationale, android.R.string.ok,
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            // Request permission
                            startLocationPermissionRequest();
                        }
                    });

        } else {
            Log.i(TAG, "Requesting permission");
            // Request permission. It's possible this can be auto answered if device policy
            // sets the permission in a given state or the user denied the permission
            // previously and checked "Never ask again".
            startLocationPermissionRequest();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        Log.i(TAG, "onRequestPermissionResult");
        if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
            if (grantResults.length <= 0) {
                // If user interaction was interrupted, the permission request is cancelled and you
                // receive empty arrays.
                Log.i(TAG, "User interaction was cancelled.");
            } else if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted.
                getLastLocation();
            } else {
                // Permission denied.

                // Notify the user via a SnackBar that they have rejected a core permission for the
                // app, which makes the Activity useless. In a real app, core permissions would
                // typically be best requested during a welcome-screen flow.

                // Additionally, it is important to remember that a permission might have been
                // rejected without asking the user for permission (device policy or "Never ask
                // again" prompts). Therefore, a user interface affordance is typically implemented
                // when permissions are denied. Otherwise, your app could appear unresponsive to
                // touches or interactions which have required permissions.
                showSnackbar(R.string.permission_denied_explanation, R.string.settings,
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                // Build intent that displays the App settings screen.
                                Intent intent = new Intent();
                                intent.setAction(
                                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                Uri uri = Uri.fromParts("package",
                                        BuildConfig.APPLICATION_ID, null);
                                intent.setData(uri);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        });
            }
        }
    }
    public void signup() {
        String usertype=spnUsertype.getSelectedItem().toString();
        String nama = _nameText.getText().toString();
        String nama_toko = _namaToko.getText().toString();
        String kabupaten=id_kab;
        String kecamatan=id_kec;
        String alamat = _addressText.getText().toString();
        String email = _emailText.getText().toString();
        String tlp = _mobileText.getText().toString();
        String password = _passwordText.getText().toString();
        String reEnterPassword = _reEnterPasswordText.getText().toString();

        if (TextUtils.isEmpty(nama) || nama.length() < 3) {
            Toast.makeText(this, "Isi Nama Minimal 3 Karakter!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(alamat)) {
            Toast.makeText(this, "Alamat tidak boleh kosong !", Toast.LENGTH_SHORT).show();
            return;
        }

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            _emailText.setError("Masukan email yang valid ");
            return;
        }

        if (TextUtils.isEmpty(tlp) || tlp.length() < 11) {
            Toast.makeText(this, "Isi No Handphone Minimal 11 Karakter!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(password) || password.length() < 4 ) {
            Toast.makeText(this, "Isi Password Minimal 4 Karakter!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(reEnterPassword) || reEnterPassword.length() < 4 || !(reEnterPassword.equals(password))) {
            _reEnterPasswordText.setError("Password Tidak Sama");
            return;
        }



        final ProgressDialog progressDialog = new ProgressDialog(SignupActivity.this, R.style.AppTheme_Dark_Dialog);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Pendaftaran Akun...");
        progressDialog.show();



        registerService = new RegisterService(this);
        registerService.doRegister(nama_toko,nama,alamat,tlp,kecamatan,kabupaten,lat,lang,usertype,email,password, new Callback() {
            @Override
            public void onResponse(Call call, Response response) {
                User baseResponse = (User) response.body();

                if (baseResponse.getCode()==1) {
                    progressDialog.dismiss();
                        LoginActivity.start(SignupActivity.this);
                        SignupActivity.this.finish();


                    Toast.makeText(SignupActivity.this, baseResponse.getMessage(), Toast.LENGTH_SHORT).show();


                }else{
                    progressDialog.dismiss();
                    Toast.makeText(SignupActivity.this, baseResponse.getMessage(), Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onFailure(Call call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(SignupActivity.this, "Jaringan Mengalami Gangguan!", Toast.LENGTH_SHORT).show();

            }
        });


    }




public void aturmenu(){

        spnUsertype.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (spnUsertype.getSelectedItem().equals("Toko Online")) {
                    TextToko.setVisibility(View.VISIBLE);
                }else{
                    TextToko.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }


    public class MyCustomAdapter extends ArrayAdapter<String> {

        public MyCustomAdapter(Context context, int textViewResourceId, List<String> objects) {
            super(context, textViewResourceId, objects);
            // TODO Auto-generated constructor stub
        }

        @Override
        public View getDropDownView(int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            return getCustomView(position, convertView, parent);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            return getCustomView(position, convertView, parent);

        }


        public View getCustomView(int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            //return super.getView(position, convertView, parent);

            LayoutInflater inflater = getLayoutInflater();
            View row = inflater.inflate(R.layout.row, parent, false);
            TextView label = (TextView) row.findViewById(R.id.Item);
            label.setText(listSpinner.get(position));
            ImageView icon = (ImageView) row.findViewById(R.id.icon);

            return row;
        }
    }

    public class MyCustomAdapterKab extends ArrayAdapter<String> {

        public MyCustomAdapterKab(Context context, int textViewResourceId, List<String> objects) {
            super(context, textViewResourceId, objects);
            // TODO Auto-generated constructor stub
        }

        @Override
        public View getDropDownView(int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            return getCustomView(position, convertView, parent);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            return getCustomView(position, convertView, parent);

        }


        public View getCustomView(int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            //return super.getView(position, convertView, parent);

            LayoutInflater inflater = getLayoutInflater();
            View row = inflater.inflate(R.layout.row, parent, false);
            TextView label = (TextView) row.findViewById(R.id.Item);
            label.setText(listSpinnerKab.get(position));
            ImageView icon = (ImageView) row.findViewById(R.id.icon);

            return row;
        }
    }

    public class MyCustomAdapterKec extends ArrayAdapter<String> {

        public MyCustomAdapterKec(Context context, int textViewResourceId, List<String> objects) {
            super(context, textViewResourceId, objects);
            // TODO Auto-generated constructor stub
        }

        @Override
        public View getDropDownView(int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            return getCustomView(position, convertView, parent);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            return getCustomView(position, convertView, parent);

        }


        public View getCustomView(int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            //return super.getView(position, convertView, parent);

            LayoutInflater inflater = getLayoutInflater();
            View row = inflater.inflate(R.layout.row, parent, false);
            TextView label = (TextView) row.findViewById(R.id.Item);
            label.setText(listSpinnerKec.get(position));
            ImageView icon = (ImageView) row.findViewById(R.id.icon);

            return row;
        }
    }


    public void getKab() {


        getkabservice = new getKabupatenService(this);
        getkabservice.doGetKab(new Callback() {
            @Override
            public void onResponse(Call call, Response response) {

                Kabupaten kab = (Kabupaten) response.body();
                if (kab.getCode() == 1) {
                    listSpinnerKab = new ArrayList<String>();
                    listSpinnerKab1 = new ArrayList<String>();
                    for (int i = 0; i < kab.getData().size(); i++) {
                        listSpinnerKab.add(kab.getData().get(i).getNama());
                        listSpinnerKab1.add(kab.getData().get(i).getId());
                        spnKabupaten.setAdapter(new MyCustomAdapterKab(SignupActivity.this, R.layout.row, listSpinnerKab));
                    }

                } else {
                    Toast.makeText(SignupActivity.this, "Tidak Ada Data", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call call, Throwable t) {

            }
        });
    }

    public void SpnKab() {
        getKab();
        spnKabupaten.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long idz) {
                String nama = parent.getItemAtPosition(position).toString();
                id_kab =listSpinnerKab1.get(position).toString();
                String id=id_kab;


                getkecservice = new getKecamatanService(SignupActivity.this);
                getkecservice.doGetKec(id, new Callback() {
                    @Override
                    public void onResponse(Call call, Response response) {


                        Kecamatan kec = (Kecamatan) response.body();
                        if (kec.getCode() == 1) {
                            listSpinnerKec = new ArrayList<String>();
                            listSpinnerKec1 = new ArrayList<String>();

                            for (int i = 0; i < kec.getData().size(); i++) {
                                listSpinnerKec.add(kec.getData().get(i).getNama());
                                id_kec=kec.getData().get(i).getId();


                            }
                            spnKecamatan.setAdapter(new MyCustomAdapterKec(SignupActivity.this, R.layout.row, listSpinnerKec));

                        }else {

                            Toast.makeText(SignupActivity.this, "Tidak Ada Data", Toast.LENGTH_SHORT).show();
                        }
                    }


                    @Override
                    public void onFailure(Call call, Throwable t) {


                    }
                });


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }

   }