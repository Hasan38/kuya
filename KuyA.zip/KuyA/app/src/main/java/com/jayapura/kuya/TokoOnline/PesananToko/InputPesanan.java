package com.jayapura.kuya.TokoOnline.PesananToko;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.text.Editable;
import android.text.Selection;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.jayapura.kuya.Kurir.Model.Toko;
import com.jayapura.kuya.Model.Pesanan;
import com.jayapura.kuya.Model.User;
import com.jayapura.kuya.R;
import com.jayapura.kuya.koneksi.PrefUtil;
import com.jayapura.kuya.koneksi.Service.InputPesananService;
import com.jayapura.kuya.koneksi.Service.getKurirService;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InputPesanan extends Fragment {
    private EditText nama_customer, input_address, input_mobile2, input_mobile1, ongkir_barang, harga_barang, jenis_barang1;
    private Spinner spnKurir;
    private TextView Kembali;
    getKurirService service;
    InputPesananService inputservice;
    private List<String> listSpinnerKurir;
    private Button btn_simpan;

    String id_kurir1, id_kurir, id_toko, nama_pelanggan, tlp_pelanggan1, tlp_pelanggan2, jenis_barang, harga, ongkir, alamat_pelanggan;

    @Nullable
    @SuppressLint("MissingPermission")

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.main_input_pesanan, container, false);
        nama_customer = view.findViewById(R.id.nama_customer);
        input_address = view.findViewById(R.id.input_address);
        input_mobile1 = view.findViewById(R.id.input_mobile1);
        input_mobile2 = view.findViewById(R.id.input_mobile2);
        ongkir_barang = view.findViewById(R.id.ongkir_barang);


        harga_barang = view.findViewById(R.id.harga_barang);
        jenis_barang1 = view.findViewById(R.id.jenis_barang);
        spnKurir = view.findViewById(R.id.spnKurir);
        btn_simpan = view.findViewById(R.id.btn_simpan);
        Kembali = view.findViewById(R.id.Kembali);


        btn_simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input();
            }
        });

        getKurir();

        Kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.FrameToko, new PesananBaruActivity()).commit();
            }
        });

        harga_barang.addTextChangedListener(new TextWatcher() {
            private String current = "";

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().equals(current)) {
                    harga_barang.removeTextChangedListener(this);


                    String cleanString = s.toString().replaceAll("\\D", "");
                    if (cleanString.length() > 0) {
                        double parsed = Double.parseDouble(cleanString);
                        Locale localeID = new Locale("in", "ID");
                        NumberFormat formatter = NumberFormat.getCurrencyInstance(localeID);
                        formatter.setMaximumFractionDigits(0);
                        current = formatter.format(parsed);
                    } else {
                        current = cleanString;
                    }


                    harga_barang.setText(current);
                    harga_barang.setSelection(current.length());
                    harga_barang.addTextChangedListener(this);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
        });

        ongkir_barang.addTextChangedListener(new TextWatcher() {
            private String current = "";

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().equals(current)) {
                    ongkir_barang.removeTextChangedListener(this);


                    String cleanString = s.toString().replaceAll("\\D", "");
                    if (cleanString.length() > 0) {
                        double parsed = Double.parseDouble(cleanString);
                        Locale localeID = new Locale("in", "ID");
                        NumberFormat formatter = NumberFormat.getCurrencyInstance(localeID);
                        formatter.setMaximumFractionDigits(0);
                        current = formatter.format(parsed);
                    } else {
                        current = cleanString;
                    }


                    ongkir_barang.setText(current);
                    ongkir_barang.setSelection(current.length());
                    ongkir_barang.addTextChangedListener(this);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
        });

        return view;

    }


    @Override
    public void onResume() {
        super.onResume();

        if (getView() == null) {
            return;
        }

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    MenuPesanan mainHomeFragment = new MenuPesanan();
                    FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.FrameToko, mainHomeFragment);
                    fragmentTransaction.commit();


                    return true;

                }
                return false;
            }
        });
    }

    public class MyCustomAdapterKurir extends ArrayAdapter<String> {

        public MyCustomAdapterKurir(Context context, int textViewResourceId, List<String> objects) {
            super(context, textViewResourceId, objects);
            // TODO Auto-generated constructor stub
        }

        @Override
        public View getDropDownView(int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            return getCustomView(position, convertView, parent);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            return getCustomView(position, convertView, parent);

        }


        public View getCustomView(int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            //return super.getView(position, convertView, parent);

            LayoutInflater inflater = getLayoutInflater();
            View row = inflater.inflate(R.layout.row, parent, false);
            TextView label = (TextView) row.findViewById(R.id.Item);
            label.setText(listSpinnerKurir.get(position));
            ImageView icon = (ImageView) row.findViewById(R.id.icon);

            return row;
        }
    }

    public void getKurir() {


        service = new getKurirService(getActivity());
        service.doGetKurir(new Callback() {
            @Override
            public void onResponse(Call call, Response response) {

                Toko toko = (Toko) response.body();
                if (toko.getCode() == 1) {
                    listSpinnerKurir = new ArrayList<String>();
                    for (int i = 0; i < toko.getData().size(); i++) {
                        listSpinnerKurir.add(toko.getData().get(i).getNama());
                        id_kurir1 = toko.getData().get(i).getId();
                        spnKurir.setAdapter(new MyCustomAdapterKurir(getActivity(), R.layout.row, listSpinnerKurir));
                    }

                } else {
                    Toast.makeText(getActivity(), "Tidak Ada Data", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call call, Throwable t) {

            }
        });
    }

    public void input() {
        User user = PrefUtil.getUser(getActivity(), PrefUtil.USER_SESSION);
        id_toko = user.getData().get(0).getId();

        nama_pelanggan = nama_customer.getText().toString();
        tlp_pelanggan1 = input_mobile1.getText().toString();
        tlp_pelanggan2 = input_mobile2.getText().toString();
        jenis_barang = jenis_barang1.getText().toString();
        harga = harga_barang.getText().toString();
        ongkir = ongkir_barang.getText().toString();
        alamat_pelanggan = input_address.getText().toString();
        id_kurir = id_kurir1;


        if (TextUtils.isEmpty(nama_pelanggan)) {
            Toast.makeText(getActivity(), "Isi Nama Pelanggan !", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(tlp_pelanggan1)) {
            Toast.makeText(getActivity(), "Tlp 1tidak boleh kosong !", Toast.LENGTH_SHORT).show();
            return;
        }


        if (TextUtils.isEmpty(jenis_barang)) {
            Toast.makeText(getActivity(), "Isi Jenis Barang!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(harga)) {
            Toast.makeText(getActivity(), "Harga Harus Diisi!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(ongkir)) {
            Toast.makeText(getActivity(), "Ongkos Kirim Harus diisi!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(alamat_pelanggan)) {
            Toast.makeText(getActivity(), "Alamat Harus diisi!", Toast.LENGTH_SHORT).show();
            return;
        }


        final ProgressDialog progressDialog = new ProgressDialog(getActivity(), R.style.AppTheme_Dark_Dialog);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Pendaftaran Akun...");
        progressDialog.show();


        inputservice = new InputPesananService(getActivity());
        inputservice.doInput(id_kurir, id_toko, nama_pelanggan, tlp_pelanggan1, tlp_pelanggan2, jenis_barang, harga, ongkir, alamat_pelanggan, new Callback() {
            @Override
            public void onResponse(Call call, Response response) {
                Pesanan pesanan = (Pesanan) response.body();

                if (pesanan.getCode() == 1) {
                    progressDialog.dismiss();

                    getFragmentManager().beginTransaction().replace(R.id.FrameToko, new PesananBaruActivity()).commit();
                    Toast.makeText(getActivity(), pesanan.getMessage(), Toast.LENGTH_SHORT).show();


                } else {
                    progressDialog.dismiss();
                    Toast.makeText(getActivity(), pesanan.getMessage(), Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onFailure(Call call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getActivity(), "Bad Connection", Toast.LENGTH_SHORT).show();

            }
        });

    }

}

