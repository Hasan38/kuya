package com.jayapura.kuya.koneksi.Service;

import android.content.Context;

import com.jayapura.kuya.koneksi.ApiInterface;
import com.jayapura.kuya.koneksi.RetrofitBuilder;

import retrofit2.Callback;

public class RegisterService {
    private ApiInterface api;

    public  RegisterService(Context context) {

        api = RetrofitBuilder.builder(context)
                .create(ApiInterface.class);
    }

    public void doRegister(String nama_toko,String nama,String alamat,String tlp,String kecamatan,String kabupaten,double lat,double lang,String usertype,String email, String password, Callback callback) {

        api.register(nama_toko,nama,alamat,tlp,kecamatan,kabupaten,lat,lang,usertype,email,password).enqueue(callback);
    }
}
