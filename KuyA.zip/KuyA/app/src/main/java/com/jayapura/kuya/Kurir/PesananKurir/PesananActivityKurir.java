package com.jayapura.kuya.Kurir.PesananKurir;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.jayapura.kuya.Kurir.Adapter.PesananKurirAdapter;
import com.jayapura.kuya.BuildConfig;
import com.jayapura.kuya.Constant;
import com.jayapura.kuya.Model.Pesanan;
import com.jayapura.kuya.Model.User;
import com.jayapura.kuya.R;
import com.jayapura.kuya.RecyclerItemClickListener;
import com.jayapura.kuya.koneksi.PrefUtil;
import com.jayapura.kuya.koneksi.Service.getPesananKurirService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PesananActivityKurir extends Fragment {

    private static final String TAG = PesananActivityKurir.class.getSimpleName();
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;

    private PesananKurirAdapter adapter;
    private Toolbar toolbarMain;
    String id_kurir;
    private TextView txtPaket;
    double lat, lang;
    ProgressBar progressBar;
    getPesananKurirService getservice;
    private static final int REQUEST_PERMISSIONS_REQUEST_CODE = 34;
    private FusedLocationProviderClient mFusedLocationClient;

    protected Location mLastLocation;

    public PesananActivityKurir() {
        // Required empty public constructor
    }


    @Nullable
    @SuppressLint("MissingPermission")

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.baris_pesanan_kurir, container, false);


        txtPaket=view.findViewById(R.id.txtPaket);
        TextView Kembali=view.findViewById(R.id.Kembali);




        progressBar = view.findViewById(R.id.prograss);
        recyclerView = view.findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(getActivity());

        Kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuPesanan()).commit();
            }
        });




        if (!checkPermissions()) {
            requestPermissions();
        } else {
            getLastLocation();

        }

        final SwipeRefreshLayout dorefresh = view.findViewById(R.id.swipeRefresh);
        dorefresh.setColorSchemeResources(android.R.color.holo_blue_bright, android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_red_light);

        /*event ketika widget dijalankan*/
        dorefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refreshItem();
            }

            void refreshItem() {
                getLastLocation();
                onItemLoad();
            }

            void onItemLoad() {
                dorefresh.setRefreshing(false);
            }

        });


        return view;
    }






    @SuppressWarnings("MissingPermission")
    private void getLastLocation() {
        mFusedLocationClient.getLastLocation()
                .addOnCompleteListener(getActivity(), new OnCompleteListener<Location>() {
                    @Override
                    public void onComplete(@NonNull Task<Location> task) {
                        if (task.isSuccessful() && task.getResult() != null) {
                            mLastLocation = task.getResult();
                            lat=mLastLocation.getLatitude();
                            lang=mLastLocation.getLongitude();
                            User user = PrefUtil.getUser(getActivity(), PrefUtil.USER_SESSION);
                            id_kurir = user.getData().get(0).getId();

                            getservice = new getPesananKurirService(getActivity());
                            getservice.doGetPesananKurir(id_kurir, lat, lang, new Callback() {

                                @Override
                                public void onResponse(Call call, Response response) {
                                    progressBar.setVisibility(View.GONE);
                                    Pesanan pesanan = (Pesanan) response.body();
                                    try {
                                        if (pesanan.getCode() == 1) {
                                            adapter = new PesananKurirAdapter(pesanan, getActivity());
                                            recyclerView.setAdapter(adapter);
                                            adapter.notifyDataSetChanged();
                                            txtPaket.setText("Jumlah Paket: "+pesanan.getPaket()+" Paket");
                                            initDataIntent(pesanan);
                                        } else {


                                            getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuPesanan()).commit();
                                        }
                                    }catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }

                                @Override
                                public void onFailure(Call call, Throwable t) {

                                    progressBar.setVisibility(View.GONE);

                                }
                            });


                    } else {
                            Log.w(TAG, "getLastLocation:exception", task.getException());

                        }
                    }
                });
    }
    private boolean checkPermissions() {
        int permissionState = ActivityCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_COARSE_LOCATION);
        return permissionState == PackageManager.PERMISSION_GRANTED;
    }
    private void showSnackbar(final int mainTextStringId, final int actionStringId,
                              View.OnClickListener listener) {

        Snackbar.make(getView().findViewById(android.R.id.content),
                getString(mainTextStringId),
                Snackbar.LENGTH_INDEFINITE)
                .setAction(getString(actionStringId), listener).show();
    }
    private void startLocationPermissionRequest() {
        ActivityCompat.requestPermissions(getActivity(),
                new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                REQUEST_PERMISSIONS_REQUEST_CODE);
    }

    private void requestPermissions() {
        boolean shouldProvideRationale =
                ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                        Manifest.permission.ACCESS_COARSE_LOCATION);

        // Provide an additional rationale to the user. This would happen if the user denied the
        // request previously, but didn't check the "Don't ask again" checkbox.
        if (shouldProvideRationale) {
            Log.i(TAG, "Displaying permission rationale to provide additional context.");

            showSnackbar(R.string.permission_rationale, android.R.string.ok,
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            // Request permission
                            startLocationPermissionRequest();
                        }
                    });

        } else {
            Log.i(TAG, "Requesting permission");
            // Request permission. It's possible this can be auto answered if device policy
            // sets the permission in a given state or the user denied the permission
            // previously and checked "Never ask again".
            startLocationPermissionRequest();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        Log.i(TAG, "onRequestPermissionResult");
        if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
            if (grantResults.length <= 0) {
                // If user interaction was interrupted, the permission request is cancelled and you
                // receive empty arrays.
                Log.i(TAG, "User interaction was cancelled.");
            } else if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted.
                getLastLocation();
            } else {
                // Permission denied.

                // Notify the user via a SnackBar that they have rejected a core permission for the
                // app, which makes the Activity useless. In a real app, core permissions would
                // typically be best requested during a welcome-screen flow.

                // Additionally, it is important to remember that a permission might have been
                // rejected without asking the user for permission (device policy or "Never ask
                // again" prompts). Therefore, a user interface affordance is typically implemented
                // when permissions are denied. Otherwise, your app could appear unresponsive to
                // touches or interactions which have required permissions.
                showSnackbar(R.string.permission_denied_explanation, R.string.settings,
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                // Build intent that displays the App settings screen.
                                Intent intent = new Intent();
                                intent.setAction(
                                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                Uri uri = Uri.fromParts("package",
                                        BuildConfig.APPLICATION_ID, null);
                                intent.setData(uri);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        });
            }
        }
    }
    @Override
    public void onResume() {
        super.onResume();

        if(getView() == null){
            return;
        }

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK){
                    MenuPesanan mainHomeFragment = new MenuPesanan();
                    FragmentTransaction fragmentTransaction =
                            getActivity().getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.FrameKurir, mainHomeFragment);
                    fragmentTransaction.commit();


                    return true;

                }
                return false;
            }
        });
    }

    private void initDataIntent(final Pesanan pesanan) {
        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(), new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                String no_pesan = pesanan.getData().get(position).getNo_pesan();
                String alamat_pelanggan = pesanan.getData().get(position).getAlamat_pelanggan();
                String tlp_pelanggan1 = pesanan.getData().get(position).getTlp_pelanggan1();
                String tlp_pelanggan2= pesanan.getData().get(position).getTlp_pelanggan2();
                String nama_toko = pesanan.getData().get(position).getNama_toko();
                String ongkir=pesanan.getData().get(position).getOngkir();
                String harga=pesanan.getData().get(position).getHarga();
                String lat=String.valueOf(pesanan.getData().get(position).getLat());
                String lang= String.valueOf(pesanan.getData().get(position).getLang());
                String tlp_toko= pesanan.getData().get(position).getTlp_toko();
                String nama_pelanggan=pesanan.getData().get(position).getNama_pelanggan();


                Bundle detailpesanan = new Bundle();
                detailpesanan.putString(Constant.KEY_PesananNoPesanan, no_pesan);
                detailpesanan.putString(Constant.KEY_PesananAlamatPelanggan, alamat_pelanggan);
                detailpesanan.putString(Constant.KEY_PesananTlp1, tlp_pelanggan1);
                detailpesanan.putString(Constant.KEY_PesananTlp2, tlp_pelanggan2);
                detailpesanan.putString(Constant.KEY_PesananNamaToko, nama_toko);
                detailpesanan.putString(Constant.KEY_PesananOngkir,ongkir);
                detailpesanan.putString(Constant.KEY_PesananHarga,harga);
                detailpesanan.putString(Constant.KEY_PesananLat, lat);
                detailpesanan.putString(Constant.KEY_PesananLang, lang);
                detailpesanan.putString(Constant.KEY_PesananTlpToko, tlp_toko);
                detailpesanan.putString(Constant.KEY_PesananNamaPelanggan, nama_pelanggan);

                DetailPesananKurir fragment = new DetailPesananKurir();
                fragment.setArguments(detailpesanan);

                getFragmentManager()
                        .beginTransaction()
                        .replace(R.id.FrameKurir, fragment)
                        .commit();


            }
        }));
    }

    private void showDialog() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());

        // set title dialog
        alertDialogBuilder.setTitle("Halo brooooo?");

        // set pesan dari dialog
        alertDialogBuilder.setMessage("Tidak Ada Data......!").setIcon(R.mipmap.ic_launcher)

                .setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new MenuPesanan()).commit();
                    }
                });


        // membuat alert dialog dari builder
        AlertDialog alertDialog = alertDialogBuilder.create();

        // menampilkan alert dialog
        alertDialog.show();
    }



}