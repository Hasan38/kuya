package com.jayapura.kuya.TokoOnline.PesananToko;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.jayapura.kuya.Constant;
import com.jayapura.kuya.R;

import java.text.NumberFormat;
import java.util.Locale;

public class DetailPesananBaru extends Fragment implements OnMapReadyCallback {





    private GoogleMap mMap;
    private TextView imgTlp1, imgTlp2,txtNoPesanan, txtNamaToko, Kembali, txtAlamat, txtTlpToko, txtHarga, txtOngkir, txtNama, txtTotal;
    private ProgressDialog progressDialog;
    String no_pesan, lat, lang, nama_pelanggan, alamat_pelanggan, tlp_pelanggan1, tlp_pelanggan2, nama_toko, tlp_toko, ongkir, harga;


    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.main_pesanan_baru_toko, container, false);
        txtNama = view.findViewById(R.id.txtNama);
        txtNamaToko = (TextView) view.findViewById(R.id.txtNamaToko);
        txtAlamat = (TextView) view.findViewById(R.id.txtAlamat);


        txtHarga = (TextView) view.findViewById(R.id.txtHarga);
        txtOngkir = (TextView) view.findViewById(R.id.txtOngkir);
        txtTotal = (TextView) view.findViewById(R.id.txtTotal);
        txtTlpToko = view.findViewById(R.id.txtTlpToko);
        imgTlp1 = view.findViewById(R.id.txtTlp1);
        imgTlp2 = view.findViewById(R.id.txtTlp2);
        Kembali = view.findViewById(R.id.Kembali);

        txtNoPesanan=view.findViewById(R.id.txtNoPesanan);

        Bundle bundle = this.getArguments();

        nama_pelanggan = bundle.getString(Constant.KEY_PesananNamaPelanggan);
        nama_toko = bundle.getString(Constant.KEY_PesananNamaToko);
        no_pesan=bundle.getString(Constant.KEY_PesananNoPesanan);
        alamat_pelanggan = bundle.getString(Constant.KEY_PesananAlamatPelanggan);
        tlp_pelanggan1 = bundle.getString(Constant.KEY_PesananTlp1);
        tlp_pelanggan2 = bundle.getString(Constant.KEY_PesananTlp2);
        ongkir = bundle.getString(Constant.KEY_PesananOngkir);
        harga = bundle.getString(Constant.KEY_PesananHarga);
        tlp_toko = bundle.getString(Constant.KEY_PesananTlpToko);
        lat = bundle.getString(Constant.KEY_PesananLat);
        lang = bundle.getString(Constant.KEY_PesananLang);
        double ongkir1 = Double.parseDouble(ongkir);
        double harga1 = Double.parseDouble(harga);
        double total = ongkir1 + harga1;
        progressDialog = new ProgressDialog(getActivity());

        Locale localeID = new Locale("in", "ID");
        NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(localeID);
        txtOngkir.setText("Ongkir : " + formatRupiah.format((double) ongkir1));
        txtHarga.setText("Harga : " + formatRupiah.format((double) harga1));
        txtTotal.setText("Total : " + formatRupiah.format((double) total));
        txtNoPesanan.setText("No. Pesanan : " + no_pesan);
        txtNama.setText("Nama : " + nama_pelanggan);
        txtNamaToko.setText(nama_toko);
        txtAlamat.setText(alamat_pelanggan);
        imgTlp1.setText(tlp_pelanggan1);
        imgTlp2.setText(tlp_pelanggan2);
        txtTlpToko.setText(tlp_toko);
        setUp();

        setPermisi();
        final LinearLayout linear1 = (LinearLayout) view.findViewById(R.id.linear1);
        final LinearLayout linear2 = (LinearLayout) view.findViewById(R.id.linear2);
        final LinearLayout linearPengirim = (LinearLayout) view.findViewById(R.id.linearPengirim);
        final LinearLayout linearPengirimIsi = (LinearLayout) view.findViewById(R.id.linearPengirimIsi);
        final LinearLayout isiCustomer = (LinearLayout) view.findViewById(R.id.isiCustomer);

        Kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.FrameToko, new PesananBaruActivity()).commit();
            }
        });
        imgTlp1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialContactPhoneTlp1();
            }
        });

        imgTlp2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialContactPhoneTlp2();
            }
        });

        txtTlpToko.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialContactPhoneToko();
            }
        });
        linear1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                linear2.setVisibility(View.VISIBLE);
                linear1.setVisibility(View.GONE);
                isiCustomer.setVisibility(View.VISIBLE);

            }
        });

        linear2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                linear2.setVisibility(View.GONE);
                linear1.setVisibility(View.VISIBLE);
                isiCustomer.setVisibility(View.GONE);


            }
        });
        linearPengirim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                linearPengirimIsi.setVisibility(View.VISIBLE);
                linearPengirim.setVisibility(View.GONE);
                txtNamaToko.setVisibility(View.VISIBLE);
                txtTlpToko.setVisibility(View.VISIBLE);

            }
        });

        linearPengirimIsi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                linearPengirimIsi.setVisibility(View.GONE);
                linearPengirim.setVisibility(View.VISIBLE);
                txtNamaToko.setVisibility(View.GONE);
                txtTlpToko.setVisibility(View.GONE);


            }
        });








        return view;
    }

    public void setPermisi() {
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            // Permission is not granted
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)) {
                Toast.makeText(getActivity(), "Membutuhkan Izin Lokasi", Toast.LENGTH_SHORT).show();
            } else {

                // No explanation needed; request the permission
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
            }
        }

    }


    public void setUp() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            SupportMapFragment mMapFragment;
            mMapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);

            mMapFragment.getMapAsync(this);


            // Call some material design APIs here
        } else {


            SupportMapFragment mMapFragment;
            mMapFragment = (SupportMapFragment) getFragmentManager().findFragmentById(R.id.map);

            mMapFragment.getMapAsync(this);
            // Implement this feature without material design

        }


    }


    @Override
    public void onResume() {
        super.onResume();

        if (getView() == null) {
            return;
        }

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    PesananBaruActivity mainHomeFragment = new PesananBaruActivity ();
                    FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.FrameToko, mainHomeFragment);
                    fragmentTransaction.commit();


                    return true;

                }
                return false;
            }
        });
    }

    private void dialContactPhoneToko() {
        String phoneNumber = tlp_toko;
        startActivity(new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phoneNumber, null)));
    }

    private void dialContactPhoneTlp1() {
        String phoneNumber = tlp_pelanggan1;
        startActivity(new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phoneNumber, null)));
    }

    private void dialContactPhoneTlp2() {
        String phoneNumber = tlp_pelanggan2;
        startActivity(new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phoneNumber, null)));
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        getAllDataLocationLatLng();
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mMap.setMyLocationEnabled(true);
    }


    /**
     * method ini digunakan menampilkan data marker dari database
     */
    private void getAllDataLocationLatLng() {

        //set latlng nya
        LatLng location = new LatLng(Double.parseDouble(lat), Double.parseDouble(lang));
        LatLng loc = new LatLng(Double.parseDouble(lat), Double.parseDouble(lang));
        //tambahkan markernya
        mMap.addMarker(new MarkerOptions().position(location).title(nama_pelanggan));
        mMap.addMarker(new MarkerOptions().position(loc).title(alamat_pelanggan));

        //set latlng index ke 0
        LatLng latLng = new LatLng(Double.parseDouble(lat), Double.parseDouble(lang));
        //lalu arahkan zooming ke marker index ke 0
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latLng.latitude, latLng.longitude), 13.0f));
    }



    }


