package com.jayapura.kuya.Kurir.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SumData {

    @SerializedName("Ambil")
    @Expose
    private String Ambil;

    @SerializedName("Pengiriman")
    @Expose
    private String Pengiriman;


    @SerializedName("Pending")
    @Expose
    private String Pending;

    public String getAmbil() {
        return Ambil;
    }

    public void setAmbil(String ambil) {
        Ambil = ambil;
    }

    public String getPengiriman() {
        return Pengiriman;
    }

    public void setPengiriman(String pengiriman) {
        Pengiriman = pengiriman;
    }

    public String getPending() {
        return Pending;
    }

    public void setPending(String pending) {
        Pending = pending;
    }

    public String getCancel() {
        return Cancel;
    }

    public void setCancel(String cancel) {
        Cancel = cancel;
    }

    @SerializedName("Cancel")
    @Expose
    private String Cancel;
}
