package com.jayapura.kuya.Kurir.Spbu;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.jayapura.kuya.Constant;
import com.jayapura.kuya.R;

public class DetailSpbu extends Fragment implements OnMapReadyCallback {

    private GoogleMap mMap;
    private TextView  txtAlamat,Kembali;
    private ProgressDialog progressDialog;
    String lat, lang,alamat;
    private ImageView btnSelsai,btnPending,btnBatal;

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.main_spbu, container, false);

        txtAlamat = (TextView) view.findViewById(R.id.txtAlamat);
        Kembali= (TextView) view.findViewById(R.id.Kembali);



        Bundle bundle = this.getArguments();


        alamat = bundle.getString(Constant.KEY_SpbuAlamat);
        lat = bundle.getString(Constant.KEY_SpbuLat);
        lang = bundle.getString(Constant.KEY_SpbuLang);


        txtAlamat.setText(alamat);

        setUp();

        setPermisi();


        Kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.FrameKurir, new SpbuActivity()).commit();
            }
        });


        return view;
    }

    public void setPermisi() {
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            // Permission is not granted
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)) {
                Toast.makeText(getActivity(), "Membutuhkan Izin Lokasi", Toast.LENGTH_SHORT).show();
            } else {

                // No explanation needed; request the permission
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
            }
        }

    }


    public void setUp() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            SupportMapFragment mMapFragment;
            mMapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);

            mMapFragment.getMapAsync(this);


            // Call some material design APIs here
        } else {


            SupportMapFragment mMapFragment;
            mMapFragment = (SupportMapFragment) getFragmentManager().findFragmentById(R.id.map);

            mMapFragment.getMapAsync(this);
            // Implement this feature without material design

        }


    }


    @Override
    public void onResume() {
        super.onResume();

        if (getView() == null) {
            return;
        }

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    SpbuActivity mainHomeFragment = new SpbuActivity();
                    FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.FrameKurir, mainHomeFragment);
                    fragmentTransaction.commit();


                    return true;

                }
                return false;
            }
        });
    }



    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        getAllDataLocationLatLng();
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mMap.setMyLocationEnabled(true);
    }


    /**
     * method ini digunakan menampilkan data marker dari database
     */
    private void getAllDataLocationLatLng() {

        //set latlng nya
        LatLng location = new LatLng(Double.parseDouble(lat), Double.parseDouble(lang));
        LatLng loc = new LatLng(Double.parseDouble(lat), Double.parseDouble(lang));
        //tambahkan markernya

        mMap.addMarker(new MarkerOptions().position(loc).title(alamat));

        //set latlng index ke 0
        LatLng latLng = new LatLng(Double.parseDouble(lat), Double.parseDouble(lang));
        //lalu arahkan zooming ke marker index ke 0
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latLng.latitude, latLng.longitude), 13.0f));
    }



    }

