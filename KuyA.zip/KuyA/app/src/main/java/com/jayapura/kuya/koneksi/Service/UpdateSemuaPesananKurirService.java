package com.jayapura.kuya.koneksi.Service;

import android.content.Context;

import com.jayapura.kuya.koneksi.ApiInterface;
import com.jayapura.kuya.koneksi.RetrofitBuilder;

import retrofit2.Callback;

public class UpdateSemuaPesananKurirService {

    private ApiInterface api;

    public  UpdateSemuaPesananKurirService (Context context) {

        api = RetrofitBuilder.builder(context)
                .create(ApiInterface.class);
    }

    public void doUpdate(String no_pesan, String status_pesanan, Callback callback) {

        api.updateSemuaPesanan(no_pesan,status_pesanan).enqueue(callback);
    }
}
