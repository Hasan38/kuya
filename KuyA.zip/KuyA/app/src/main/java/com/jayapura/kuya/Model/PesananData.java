package com.jayapura.kuya.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PesananData {
    @SerializedName("no_pesan")
    @Expose
    private String no_pesan;

    @SerializedName("id_toko")
    @Expose
    private String id_toko;

    @SerializedName("nama_pelanggan")
    @Expose
    private String nama_pelanggan;

    @SerializedName("tlp_pelanggan1")
    @Expose
    private String tlp_pelanggan1;

    @SerializedName("tlp_pelanggan2")
    @Expose
    private String tlp_pelanggan2;

    @SerializedName("jenis_barang")
    @Expose
    private String jenis_barang;

    @SerializedName("harga")
    @Expose
    private String harga;

    @SerializedName("ongkir")
    @Expose
    private String ongkir;

    @SerializedName("lat")
    @Expose
    private String lat;

    @SerializedName("lang")
    @Expose
    private String lang;

    public String getJarak() {
        return jarak;
    }

    public void setJarak(String jarak) {
        this.jarak = jarak;
    }

    @SerializedName("jarak")
    @Expose
    private String jarak;

    public String getTlp_toko() {
        return tlp_toko;
    }

    public void setTlp_toko(String tlp_toko) {
        this.tlp_toko = tlp_toko;
    }

    @SerializedName("tlp_toko")
    @Expose
    private String tlp_toko;


    @SerializedName("alamat_pelanggan")
    @Expose
    private String alamat_pelanggan;

    @SerializedName("tgl_buat")
    @Expose
    private String tgl_buat;

    public String getNama_toko() {
        return nama_toko;
    }

    public void setNama_toko(String nama_toko) {
        this.nama_toko = nama_toko;
    }

    @SerializedName("nama_toko")
    @Expose
    private String nama_toko;

    @SerializedName("tgl_pengiriman")
    @Expose
    private String tgl_pengiriman;

    public String getNo_pesan() {
        return no_pesan;
    }

    public void setNo_pesan(String no_pesanan) {
        this.no_pesan = no_pesanan;
    }

    public String getId_toko() {
        return id_toko;
    }

    public void setId_toko(String id_toko) {
        this.id_toko = id_toko;
    }

    public String getNama_pelanggan() {
        return nama_pelanggan;
    }

    public void setNama_pelanggan(String nama_pelanggan) {
        this.nama_pelanggan = nama_pelanggan;
    }

    public String getTlp_pelanggan1() {
        return tlp_pelanggan1;
    }

    public void setTlp_pelanggan1(String tlp_pelanggan1) {
        this.tlp_pelanggan1 = tlp_pelanggan1;
    }

    public String getTlp_pelanggan2() {
        return tlp_pelanggan2;
    }

    public void setTlp_pelanggan2(String tlp_pelanggan2) {
        this.tlp_pelanggan2 = tlp_pelanggan2;
    }

    public String getJenis_barang() {
        return jenis_barang;
    }

    public void setJenis_barang(String jenis_barang) {
        this.jenis_barang = jenis_barang;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getOngkir() {
        return ongkir;
    }

    public void setOngkir(String ongkir) {
        this.ongkir = ongkir;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getAlamat_pelanggan() {
        return alamat_pelanggan;
    }

    public void setAlamat_pelanggan(String alamat_pelanggan) {
        this.alamat_pelanggan = alamat_pelanggan;
    }

    public String getTgl_buat() {
        return tgl_buat;
    }

    public void setTgl_buat(String tgl_buat) {
        this.tgl_buat = tgl_buat;
    }

    public String getTgl_pengiriman() {
        return tgl_pengiriman;
    }

    public void setTgl_pengiriman(String tgl_pengiriman) {
        this.tgl_pengiriman = tgl_pengiriman;
    }

    public String getId_kurir() {
        return id_kurir;
    }

    public void setId_kurir(String id_kurir) {
        this.id_kurir = id_kurir;
    }

    public String getStatus_pesanan() {
        return status_pesanan;
    }

    public void setStatus_pesanan(String status_pesanan) {
        this.status_pesanan = status_pesanan;
    }

    @SerializedName("id_kurir")
    @Expose
    private String id_kurir;

    @SerializedName("status_pesanan")
    @Expose
    private String status_pesanan;
}
